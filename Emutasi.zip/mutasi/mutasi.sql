-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2019 at 11:38 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mutasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `departemen`
--

CREATE TABLE `departemen` (
  `dept_id` varchar(16) NOT NULL,
  `nama_dept` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departemen`
--

INSERT INTO `departemen` (`dept_id`, `nama_dept`) VALUES
('DEPT-001', 'RENMIN (TANGGON KOSALA)'),
('DEPT-002', 'RENMIN (KS TUBUN)'),
('DEPT-003', 'BHAYANGKARA'),
('DEPT-004', 'TBU'),
('DEPT-005', 'SIAK');

-- --------------------------------------------------------

--
-- Table structure for table `mutasi`
--

CREATE TABLE `mutasi` (
  `mutasi_id` varchar(16) NOT NULL,
  `tanggal` date NOT NULL,
  `departemen` varchar(16) NOT NULL,
  `nama_petugas` varchar(256) NOT NULL,
  `jam` varchar(16) NOT NULL,
  `mutasi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mutasi`
--

INSERT INTO `mutasi` (`mutasi_id`, `tanggal`, `departemen`, `nama_petugas`, `jam`, `mutasi`) VALUES
('5c6fb9875ebbc', '2019-02-22', 'DEPT-001', '190222-001', ' 15:57 ', '<p style=\"margin: 0px 0px 1em; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Arial, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; vertical-align: baseline; box-sizing: inherit; clear: both; color: #242729; background-color: #ffffff;\">Above is the entirety of my login function at the moment, from my User controller. I\'ve removed all the other code in an effort to pinpoint this problem. I\'ve even commented out the&nbsp;<code style=\"margin: 0px; padding: 1px 5px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: Consolas, Menlo, Monaco, \'Lucida Console\', \'Liberation Mono\', \'DejaVu Sans Mono\', \'Bitstream Vera Sans Mono\', \'Courier New\', monospace, sans-serif; font-size: 13px; vertical-align: baseline; box-sizing: inherit; background-color: #eff0f1; white-space: pre-wrap;\">if</code>&nbsp;statement thinking that it might even by the culprit. nope.</p>\r\n<p style=\"margin: 0px 0px 1em; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Arial, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; vertical-align: baseline; box-sizing: inherit; clear: both; color: #242729; background-color: #ffffff;\">My&nbsp;<code style=\"margin: 0px; padding: 1px 5px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: Consolas, Menlo, Monaco, \'Lucida Console\', \'Liberation Mono\', \'DejaVu Sans Mono\', \'Bitstream Vera Sans Mono\', \'Courier New\', monospace, sans-serif; font-size: 13px; vertical-align: baseline; box-sizing: inherit; background-color: #eff0f1; white-space: pre-wrap;\">logged_in()</code>&nbsp;function returns TRUE, or FALSE, depending on certain things set in my user sessions. That appears to be functioning fine. As far as I can tell, my configs settings looks good. I have the URI helper autoloaded, and other URI helper methods function properly.</p>\r\n<p style=\"margin: 0px 0px 1em; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Arial, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; vertical-align: baseline; box-sizing: inherit; clear: both; color: #242729; background-color: #ffffff;\">Now for the strange part. When I visit /user/login, not only does my page not redirect, if I un-comment the&nbsp;<code style=\"margin: 0px; padding: 1px 5px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: Consolas, Menlo, Monaco, \'Lucida Console\', \'Liberation Mono\', \'DejaVu Sans Mono\', \'Bitstream Vera Sans Mono\', \'Courier New\', monospace, sans-serif; font-size: 13px; vertical-align: baseline; box-sizing: inherit; background-color: #eff0f1; white-space: pre-wrap;\">var_dump()</code>&nbsp;before the redirect (which returns true), and re-comment it, the page doesn\'t update, and I have&nbsp;<code style=\"margin: 0px; padding: 1px 5px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: Consolas, Menlo, Monaco, \'Lucida Console\', \'Liberation Mono\', \'DejaVu Sans Mono\', \'Bitstream Vera Sans Mono\', \'Courier New\', monospace, sans-serif; font-size: 13px; vertical-align: baseline; box-sizing: inherit; background-color: #eff0f1; white-space: pre-wrap;\">bool(true)</code>&nbsp;on my screen regardless. If the&nbsp;<code style=\"margin: 0px; padding: 1px 5px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: Consolas, Menlo, Monaco, \'Lucida Console\', \'Liberation Mono\', \'DejaVu Sans Mono\', \'Bitstream Vera Sans Mono\', \'Courier New\', monospace, sans-serif; font-size: 13px; vertical-align: baseline; box-sizing: inherit; background-color: #eff0f1; white-space: pre-wrap;\">var_dump</code>&nbsp;is commented and I open a new tab to&nbsp;<code style=\"margin: 0px; padding: 1px 5px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: Consolas, Menlo, Monaco, \'Lucida Console\', \'Liberation Mono\', \'DejaVu Sans Mono\', \'Bitstream Vera Sans Mono\', \'Courier New\', monospace, sans-serif; font-size: 13px; vertical-align: baseline; box-sizing: inherit; background-color: #eff0f1; white-space: pre-wrap;\">users/login</code>&nbsp;it simply doesn\'t load anything, and it just hangs out as a new tab.</p>\r\n<p style=\"margin: 0px 0px 1em; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Arial, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; vertical-align: baseline; box-sizing: inherit; clear: both; color: #242729; background-color: #ffffff;\">Edit: I\'ve forgotten to mention that when I use the \'refresh\' flag (<code style=\"margin: 0px; padding: 1px 5px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: Consolas, Menlo, Monaco, \'Lucida Console\', \'Liberation Mono\', \'DejaVu Sans Mono\', \'Bitstream Vera Sans Mono\', \'Courier New\', monospace, sans-serif; font-size: 13px; vertical-align: baseline; box-sizing: inherit; background-color: #eff0f1; white-space: pre-wrap;\">redirect(\'/user/\', \'refresh\');</code>), that simply takes me to an about:blank page.</p>\r\n<p style=\"margin: 0px 0px 1em; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Arial, \'Helvetica Neue\', Helvetica, sans-serif; font-size: 15px; vertical-align: baseline; box-sizing: inherit; clear: both; color: #242729; background-color: #ffffff;\">Edit#2: I\'ve copied the CI3 files into a new \"project\", and even those wont redirect using the built in Welcome_Message view/controller combo.</p>'),
('5c6fc86839b9b', '2019-02-22', 'DEPT-001', '190222-001', ' 17:01 ', '<p>makan</p>');

-- --------------------------------------------------------

--
-- Table structure for table `mutasi_personil`
--

CREATE TABLE `mutasi_personil` (
  `id` varchar(32) NOT NULL,
  `tgl` date NOT NULL,
  `departemen` varchar(16) NOT NULL,
  `nrp_personil` varchar(1024) NOT NULL,
  `nrp_pelaksana` varchar(32) NOT NULL,
  `nrp_penerima` varchar(32) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mutasi_personil`
--

INSERT INTO `mutasi_personil` (`id`, `tgl`, `departemen`, `nrp_personil`, `nrp_pelaksana`, `nrp_penerima`, `status`) VALUES
('190222-001', '2019-02-22', 'DEPT-001', '123456', '102222', '100111', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pangkat`
--

CREATE TABLE `pangkat` (
  `pangkat_id` varchar(16) NOT NULL,
  `pangkat` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pangkat`
--

INSERT INTO `pangkat` (`pangkat_id`, `pangkat`) VALUES
('PNGKT-001', 'IRJEN POL'),
('PNGKT-002', 'BRIGJEN POL'),
('PNGKT-003', 'KOMBES POL'),
('PNGKT-004', 'AKBP'),
('PNGKT-005', 'KOMPOL'),
('PNGKT-006', 'AKP'),
('PNGKT-007', 'IPTU'),
('PNGKT-008', 'IPDA'),
('PNGKT-009', 'AIPTU'),
('PNGKT-010', 'AIPDA'),
('PNGKT-011', 'BRIPKA'),
('PNGKT-012', 'BRIGADIR'),
('PNGKT-013', 'BRIPTU'),
('PNGKT-014', 'BRIPDA'),
('PNGKT-015', 'BHARADA');

-- --------------------------------------------------------

--
-- Table structure for table `personil`
--

CREATE TABLE `personil` (
  `nrp` varchar(32) NOT NULL,
  `nama` varchar(32) NOT NULL,
  `pangkat` varchar(32) NOT NULL,
  `departemen` varchar(32) NOT NULL,
  `pass` varchar(64) NOT NULL,
  `level` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personil`
--

INSERT INTO `personil` (`nrp`, `nama`, `pangkat`, `departemen`, `pass`, `level`) VALUES
('100111', 'Huba', 'PNGKT-015', 'DEPT-001', '202cb962ac59075b964b07152d234b70', 0),
('123456', '123456', 'PNGKT-001', 'DEPT-001', '202cb962ac59075b964b07152d234b70', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `nrp` varchar(64) NOT NULL,
  `nama` varchar(64) NOT NULL,
  `pangkat` varchar(32) NOT NULL,
  `departemen` varchar(32) NOT NULL,
  `pass` varchar(64) NOT NULL,
  `level` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`nrp`, `nama`, `pangkat`, `departemen`, `pass`, `level`) VALUES
('100001', 'Pak Eko', 'PNGKT-005', 'DEPT-002', '4b1b0cc61d24bd6ad146ed057c939119', 1),
('102222', 'Sitt', 'PNGKT-015', 'DEPT-001', '4b1b0cc61d24bd6ad146ed057c939119', 2),
('123', 'SIAK', 'PNGKT-001', 'DEPT-001', '4b1b0cc61d24bd6ad146ed057c939119', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departemen`
--
ALTER TABLE `departemen`
  ADD PRIMARY KEY (`dept_id`);

--
-- Indexes for table `mutasi`
--
ALTER TABLE `mutasi`
  ADD PRIMARY KEY (`mutasi_id`);

--
-- Indexes for table `mutasi_personil`
--
ALTER TABLE `mutasi_personil`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pangkat`
--
ALTER TABLE `pangkat`
  ADD PRIMARY KEY (`pangkat_id`);

--
-- Indexes for table `personil`
--
ALTER TABLE `personil`
  ADD PRIMARY KEY (`nrp`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`nrp`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
