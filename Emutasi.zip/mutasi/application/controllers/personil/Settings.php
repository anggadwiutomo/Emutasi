<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("personil_model");
    }

    public function index()
    {
                
        $data['title'] = 'Change Password';

        $this->load->library('form_validation');

        $this->form_validation->set_rules('oldpass', 'old password', 'callback_password_check');
        $this->form_validation->set_rules('newpass', 'new password', 'required');
        $this->form_validation->set_rules('passconf', 'confirm password', 'required|matches[newpass]');

        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

        if($this->form_validation->run() == false) {
            //$this->load->view('header', $data);
             if($this->session->userdata('akses')=='3'){
        $this->load->view('personil/setting', $data);
    }else{
        echo "Anda tidak berhak mengakses halaman ini";
    }
           
            //$this->load->view('footer', $data);
        }
        else {

            $id = $this->session->userdata('ses_nrp');

            $newpass = $this->input->post('newpass');

            $this->personil_model->update_user($id, array('pass' => md5($newpass)));
            echo "<script> alert('Password Berhasil diganti !'); 
            window.location.href='overview';
            </script>";
        //     $this->session->sess_destroy();
        //     $url=base_url('');
        // redirect($url);
          // redirect('login');
        }
    }

    
    public function password_check($oldpass)
    {
        $id = $this->session->userdata('ses_nrp');
        $user = $this->personil_model->get_user($id);

        if($user->pass !== md5($oldpass)) {
            $this->form_validation->set_message('password_check', 'The {field} does not match');
            return false;
        }

        return true;
    }

    public function keluar($id=null){
        $this->session->sess_destroy();
        redirect('login', 'refresh');
    }
}