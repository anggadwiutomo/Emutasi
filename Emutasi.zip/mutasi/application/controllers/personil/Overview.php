<?php

class Overview extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
	// load view admin/overview.php
	    //validasi jika user belum login
		if($this->session->userdata('masuk') != TRUE){
			$url=base_url();
			redirect($url);
		}
		else{
			$this->load->model('mutasi_model');
			$data["mutasi"] = $this->mutasi_model->get_daftar_mutasi2();

	    	 $this->load->model('Count_model');
    		// $isi['admin'] = $this->Count_model->admin()->num_rows();
    		// $isi['client']  = $this->Count_model->client()->num_rows();
    		// $isi['departemen'] = $this->Count_model->departemen()->num_rows();
    		// $isi['mutasi'] = $this->Count_model->mutasi()->num_rows();
			if($this->session->userdata('akses')=='3'){     
				$this->load->view("personil/overview", $data);
			}else{
				echo "Anda tidak berhak mengakses halaman ini";
			}

		}
	}

}

