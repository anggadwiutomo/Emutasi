<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Mutasi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("mutasi_model");
        $this->load->library('form_validation');
        // $this->depart = $this->session->userdata('departemen');

    }

    public function index()
    { 
        $data["mutasi"] = $this->mutasi_model->get_mutasi();
        $data["nama_penjaga"] = $this->mutasi_model->get_nama_piket();
        // $this->load->view("admin/mutasi/list", $data);


         ///Untuk Cetak Pdf
        $url_cetak = 'admin/mutasi/cetak';
       // $url_cetak_temp = 'admin/mutasi/cetak_temp';
        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model
        

        $data['url_cetak'] = base_url('index.php/'.$url_cetak);
       // $data['url_cetak_temp'] = base_url('index.php/'.$url_cetak_temp);
        // $data['mutasi'] = $mutasi;

        if($this->session->userdata('akses')=='2'){

           $this->load->view("admin/mutasi/list", $data);
       }else{
        echo "Anda tidak berhak mengakses halaman ini";
    }

    
}

      //Untuk Cetak Pdf
public function cetak()
{

        // $this->load->view("admin/mutasi/pdf", $data);

        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model

        // $data['mutasi'] = $mutasi;

    $data["mutasi"] = $this->mutasi_model->get_mutasi();
    $data["nama_penjaga"] = $this->mutasi_model->get_nama_piket();
        // $this->load->view("admin/mutasi/pdf", $data);
    
        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model

        // $data['mutasi'] = $mutasi;

    ob_start();
    if($this->session->userdata('akses')=='2'){
       $this->load->view('admin/mutasi/pdf', $data);
    }else{
    echo "Anda tidak berhak mengakses halaman ini";
    }

    $html = ob_get_contents();
    ob_end_clean();
    require_once('./assets/html2pdf/html2pdf.class.php');
    $dept = $this->session->userdata['ses_dept'];
    date_default_timezone_set('Asia/Jakarta');
    $today=strtotime(date('d-m-Y'));
    $today = date('d-m-Y',strtotime('today',$today));
    // $today=strtotime(date('today'));
    $pdf = new HTML2PDF('P','A4','en');
    $pdf->WriteHTML($html);
    $pdf->Output('Data Mutasi '.$today.' '.$dept.'.pdf', 'D');
}

public function cetak_temp($nama_petugas='')
{

        // $this->load->view("admin/mutasi/pdf", $data);

        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model

        // $data['mutasi'] = $mutasi;

    $data["mutasi"] = $this->mutasi_model->list_mutasi_by_nama2($nama_petugas);
    $data["nama_penjaga"] = $this->mutasi_model->list_mutasi_personil($nama_petugas);
        // $this->load->view("admin/mutasi/pdf", $data);
    
        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model

        // $data['mutasi'] = $mutasi;

    ob_start();
    if($this->session->userdata('akses')=='2'){

       $this->load->view('admin/mutasi/pdf', $data);
   }else{
    echo "Anda tidak berhak mengakses halaman ini";
}

$html = ob_get_contents();
ob_end_clean();

require_once('./assets/html2pdf/html2pdf.class.php');
$pdf = new HTML2PDF('P','A4','en');
$pdf->WriteHTML($html);
$pdf->Output('Data Mutasi.pdf', 'D');
}

public function print()
{
    $data["mutasi"] = $this->mutasi_model->get_mutasi();
    $data["nama_penjaga"] = $this->mutasi_model->get_nama_piket();
    if($this->session->userdata('akses')=='2'){

       $this->load->view("admin/mutasi/print", $data);
   }else{
    echo "Anda tidak berhak mengakses halaman ini";
}

}
public function print_temp($nama_petugas='')
{
    $data["mutasi"] = $this->mutasi_model->list_mutasi_by_nama2($nama_petugas);
    $data["nama_penjaga"] = $this->mutasi_model->list_mutasi_personil($nama_petugas);
    if($this->session->userdata('akses')=='2'){
        $this->load->view("admin/mutasi/print", $data);
    }else{
        echo "Anda tidak berhak mengakses halaman ini";
    }

    
}
public function get_mutasi_by_nama($nama_petugas='')
//write this way so that you can call the url like
//localhost/norwin/list_group/get_product_by_group
{

        if($nama_petugas)//no need to check uri->segment
        {
            $this->load->database();                    
            $data['mutasi'] = $this->mutasi_model->list_mutasi_by_nama2($nama_petugas);
            $data["nama_penjaga"] = $this->mutasi_model->list_mutasi_personil($nama_petugas);
           // $url_cetak_temp = 'admin/mutasi/cetak_temp';        
            //$data['url_cetak_temp'] = base_url('index.php/'.$url_cetak_temp);
            if($this->session->userdata('akses')=='2'){
                $this->load->view('admin/mutasi/list_temp', $data);
            }else{
                echo "Anda tidak berhak mengakses halaman ini";
            }
            

        }
        else
        {
            redirect('admin/overview');
        }

    }


    // public function indexby()
    // {
    //     // $departemen = $this->session->userdata['ses_dept'];
    //     $data["Mutasi"] = $this->mutasi_model->get_mutasi($departemen);
    //     $this->load->view("admin/mutasi/list", $data);
    // }



    public function add()
    {
        $data["nama_penjaga"] = $this->mutasi_model->get_nama_piket();
        $data['opt_nama'] = $this->mutasi_model->get_opt_nama();
        $mutasi = $this->mutasi_model;
        $validation = $this->form_validation;
        $validation->set_rules($mutasi->rules());        
        
        if ($validation->run()) {
            $mutasi->save();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
            redirect('/admin/mutasi/','refresh');
        }

        $this->load->view("admin/mutasi/add_mutasi",$data);

    }

    public function add_piket()
    {

        $data['idunik']=$this->mutasi_model->get_no_invoice();
        $data['opt_nama'] = $this->mutasi_model->get_opt_nama();

        $mutasi = $this->mutasi_model;
        $validation = $this->form_validation;
        $validation->set_rules($mutasi->rules2());        
        
        if ($validation->run()) {
            $mutasi->savePiket();
            // $mutasi->savePersonil();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
            redirect('/admin/mutasi','refresh');
        }

        $this->load->view("admin/mutasi/add_piket",$data);


    }
    public function nama_petugas()
    { 
        $data["mutasi"] = $this->mutasi_model->get_mutasi();
        $data["nama_penjaga"] = $this->mutasi_model->get_nama_piket();
        // $this->load->view("personil/mutasi/list", $data);


         ///Untuk Cetak Pdf
     //   $url_cetak_temp = 'personil/mutasi/cetak_temp';
        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model
        

       // $data['url_cetak_temp'] = base_url('index.php/'.$url_cetak_temp);
        // $data['mutasi'] = $mutasi;

        $this->load->view("admin/mutasi/list_piket", $data);
    }
    public function edit($id = null)
    {

        if (!isset($id)) redirect('admin/mutasi');
        
        $mutasi = $this->mutasi_model;
        $validation = $this->form_validation;
        $validation->set_rules($mutasi->rules());

        if ($validation->run()) {
            $mutasi->update();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
            redirect('/admin/mutasi/','refresh');
        }

        $data["mutasi"] = $mutasi->getById($id);
        if (!$data["mutasi"]) show_404();
        $data['opt_nama'] = $this->mutasi_model->get_opt_nama();        
        $this->load->view("admin/mutasi/edit_form", $data);
    }

    public function editPiket($id = null)
    {

        if (!isset($id)) redirect('admin/mutasi');
        
        $mutasi = $this->mutasi_model;
        $validation = $this->form_validation;
        $validation->set_rules($mutasi->rules2());

        if ($validation->run()) {
            $mutasi->updatePiket();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
            redirect('/admin/mutasi','refresh');
        }

        $data["mutasi"] = $mutasi->getByIdPiket($id);
        if (!$data["mutasi"]) show_404();
        $data['opt_nama'] = $this->mutasi_model->get_opt_nama();        
        $this->load->view("admin/mutasi/edit_form_piket", $data);
    }

    public function delete($id=null)
    {
        if (!isset($id)) show_404();
        
        if ($this->mutasi_model->delete($id)) {
            redirect(site_url('admin/mutasi'));
        }
    }
    public function editStatus($id=null)
    {
        $this->mutasi_model->updateStatus($id);
        redirect('admin/overview','refresh');
        // if (!isset($id)) show_404();
        
        // if ($this->mutasi_model->updateStatus($id)) {
        //     redirect('admin/overview','refresh');
        // }
    }
}