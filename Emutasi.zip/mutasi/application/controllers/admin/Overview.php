<?php

class Overview extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
	// load view admin/overview.php
	    //validasi jika user belum login
		if($this->session->userdata('masuk') != TRUE){
			$url=base_url();
			redirect($url);
		}
		else{

			$this->load->model('mutasi_model');
			$data["mutasi"] = $this->mutasi_model->get_daftar_mutasi2();

        // $this->load->view("admin/mutasi/list", $data);


         ///Untuk Cetak Pdf
			//$url_cetak = 'admin/mutasi/cetak';
			//$url_cetak_temp = 'admin/mutasi/cetak_temp';
        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model


			//$data['url_cetak'] = base_url('index.php/'.$url_cetak);
			//$data['url_cetak_temp'] = base_url('index.php/'.$url_cetak_temp);
        // $data['mutasi'] = $mutasi;

			$this->load->model('Count_model');
			$data['admin'] = $this->Count_model->admin_departemen()->num_rows();
			$data['personil']  = $this->Count_model->personil_departemen()->num_rows();
			$data['mutasi_total'] = $this->Count_model->mutasi_departemen()->num_rows();
			$data['penjaga'] = $this->Count_model->get_nama_piket();

			if($this->session->userdata('akses')=='2'){
				$this->load->view("admin/overview", $data);
			}else{
				echo "Anda tidak berhak mengakses halaman ini";
			}


		}	    
	}



}
