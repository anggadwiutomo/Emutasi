<?php

class Overview extends CI_Controller {
    public function __construct()
    {
      parent::__construct();
      $this->load->model('mutasi_model');
  }

  public function index()
  {

	// load view admin/overview.php
	    //validasi jika user belum login
    
      $isi["opt_dept"] = $this->mutasi_model->getDepartemen();

      // $isi["mutasix"] = $this->mutasi_model->get_all_mutasi();

	    	///Filter
        if(isset($_GET['filter']) && ! empty($_GET['filter'])){ // Cek apakah user telah memilih filter dan klik tombol tampilkan
            $filter = $_GET['filter']; // Ambil data filder yang dipilih user

            if($filter == '1'){ // Jika filter nya 1 (per tanggal)
                $tanggal = $_GET['tanggal'];

                // $ket = 'Data mutasi Tanggal '.date('d-m-y', strtotime($tanggal));
                // $url_cetak = 'admin/mutasi/cetak?filter=1&tanggal='.$tanggal;
                $mutasi = $this->mutasi_model->view_by_date3($tanggal); // Panggil fungsi view_by_date yang ada di mutasi_model
            }elseif ($filter == '2') {
              $dept = $_GET['dept'];
               // $nama_bulan = array('', 'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');

                // $ket = 'Data mutasi Bulan '.$nama_bulan[$bulan].' '.$tahun;
                // $url_cetak = 'admin/mutasi/cetak?filter=2&bulan='.$bulan.'&tahun='.$tahun;
                $mutasi = $this->mutasi_model->view_by_dept3($dept); // Panggil fungsi view_by_month yang ada di mutasi_model
            }else{ // Jika filter nya 2 (per tanggal dan departemen)
                $tanggal = $_GET['tanggal'];
                $dept = $_GET['dept'];
               // $nama_bulan = array('', 'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');

                // $ket = 'Data mutasi Bulan '.$nama_bulan[$bulan].' '.$tahun;
                // $url_cetak = 'admin/mutasi/cetak?filter=2&bulan='.$bulan.'&tahun='.$tahun;
                $mutasi = $this->mutasi_model->view_by_date_dept3($tanggal, $dept); // Panggil fungsi view_by_month yang ada di mutasi_model
            }
        }else{ // Jika user tidak mengklik tombol tampilkan
            // $ket = 'Semua Data mutasi';
            // $url_cetak = 'admin/mutasi/cetak';
            $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model
        }

        // // $data['ket'] = $ket;
        //  $data['url_cetak'] = base_url('index.php/'.$url_cetak);
        $isi['mutasix'] = $mutasi;
        //  $isi['option_tahun'] = $this->mutasi_model->option_tahun();
         // $this->load->view("superadmin/overview", $data);
        
        

        $this->load->model('Count_model');
        $isi['admin'] = $this->Count_model->admin()->num_rows();
        $isi['client']  = $this->Count_model->client()->num_rows();
        $isi['departemen'] = $this->Count_model->departemen()->num_rows();
        $isi['mutasi_total'] = $this->Count_model->mutasi()->num_rows();

        if($this->session->userdata('akses')=='1'){
            $this->load->view("superadmin/overview", $isi);
        }else{
           echo "Anda tidak berhak mengakses halaman ini";
       }   	
       
   }
}
