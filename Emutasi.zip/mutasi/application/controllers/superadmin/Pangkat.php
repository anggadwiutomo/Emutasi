<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pangkat extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model("pangkat_model");
		$this->load->library('form_validation');
	}
	
	// List all your items
	public function index()
	{
		$data["pangkat"] = $this->pangkat_model->getAll();	
		if($this->session->userdata('akses')=='1'){
			
			$this->load->view("superadmin/pangkat/list",$data);
			
		}else{
			echo "Anda tidak berhak mengakses halaman ini";
		}         
		
		

	}
	// public function kode()
	// {
	// 	$data['kodeunik'] = $this->pangkat_model->code_otomatis();
	// 	$this->load->view("superadmin/pangkat/add_pangkat",$data);
	// }
	
		// Add a new item
	public function add()
	{
		$data['kodeunik']=$this->pangkat_model->buat_kode();
		$pangkat = $this->pangkat_model;
		$validation = $this->form_validation;
		$validation->set_rules($pangkat->rules());

		if ($validation->run()) {
			$pangkat->save();
			$this->session->set_flashdata('success', 'Berhasil disimpan');
			redirect($this->uri->uri_string());

		}
		if($this->session->userdata('akses')=='1'){
			
			$this->load->view("superadmin/pangkat/add_pangkat",$data);
			
		}else{
			echo "Anda tidak berhak mengakses halaman ini";
		} 
		
	}
	
		//Update one item
	public function edit( $id = NULL )
	{
		if (!isset($id)) redirect('superadmin/pangkat');

		$pangkat = $this->pangkat_model;
		$validation = $this->form_validation;
		$validation->set_rules($pangkat->rules());

		if ($validation->run()) {
			$pangkat->update();
			$this->session->set_flashdata('success', 'Berhasil disimpan');
		}

		$data["pangkat"] = $pangkat->getById($id);
		if (!$data["pangkat"]) show_404();

		if($this->session->userdata('akses')=='1'){
			
			$this->load->view("superadmin/pangkat/edit_form", $data);
			
		}else{
			echo "Anda tidak berhak mengakses halaman ini";
		} 
		
		
		
		
	}
	
		//Delete one item
	public function delete( $id = NULL )
	{
		if (!isset($id)) show_404();
		
		if ($this->pangkat_model->delete($id)) {
			redirect(site_url('superadmin/pangkat/'));
		}
	}
}

/* End of file pangkat.php */
/* Location: ./application/controllers/pangkat.php */


