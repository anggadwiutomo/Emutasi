<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Mutasi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("mutasi_model");
        $this->load->library('form_validation');
        // $this->depart = $this->session->userdata('departemen');

    }

    public function index()
    { 
        // $data["mutasi"] = $this->mutasi_model->getAll();
        $data["mutasi"] = $this->mutasi_model->get_daftar_mutasi();

        // $data["mutasi"] = $this->mutasi_model->get_mutasi();
        // $data["nama_penjaga"] = $this->mutasi_model->get_nama_piket();
        // $this->load->view("superadmin/mutasi/list", $data);


         ///Untuk Cetak Pdf
        $url_cetak = 'superadmin/mutasi/cetak';
        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model
        

        $data['url_cetak'] = base_url('index.php/'.$url_cetak);
        // $data['mutasi'] = $mutasi;

        if($this->session->userdata('akses')=='1'){
            
            $this->load->view("superadmin/mutasi/list", $data);
            
        }else{
            echo "Anda tidak berhak mengakses halaman ini";
        }   


        
    }
    public function get_mutasi_by_nama($nama_petugas='')
//write this way so that you can call the url like
//localhost/norwin/list_group/get_product_by_group
    {

        if($nama_petugas)//no need to check uri->segment
        {
            $this->load->database();                    
            $data['mutasi'] = $this->mutasi_model->list_mutasi_by_nama($nama_petugas);
            $data["nama_penjaga"] = $this->mutasi_model->list_mutasi_personil($nama_petugas);
            $url_cetak = 'superadmin/mutasi/cetak_temp';        
            $data['url_cetak'] = base_url('index.php/'.$url_cetak);

            if($this->session->userdata('akses')=='1'){
                
                $this->load->view('superadmin/mutasi/list_temp', $data);
                
            }else{
                echo "Anda tidak berhak mengakses halaman ini";
            }   

            

        }
        else
        {
            redirect('superadmin/overview');
        }
    }
    public function get_nama_by_mutasi($nama_petugas='')
//write this way so that you can call the url like
//localhost/norwin/list_group/get_product_by_group
    {

        if($nama_petugas)//no need to check uri->segment
        {
            $this->load->database();                    
            $data['mutasi'] = $this->mutasi_model->list_nama_by_mutasi($nama_petugas);

            if($this->session->userdata('akses')=='1'){
                
             $this->load->view('superadmin/mutasi/list_nama_temp', $data);
             
         }else{
            echo "Anda tidak berhak mengakses halaman ini";
        }   
        
        

    }
    else
    {
        redirect('superadmin/overview');
    }
}
public function overvw()
{ 
    $data["mutasi"] = $this->mutasi_model->getAll();
    if($this->session->userdata('akses')=='1'){
        
        $this->load->view("superadmin/overview", $data);
        
    }else{
        echo "Anda tidak berhak mengakses halaman ini";
    }   
    
}

      //Untuk Cetak Pdf
public function cetak()
{

        // $this->load->view("superadmin/mutasi/pdf", $data);
  
        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model

        // $data['mutasi'] = $mutasi;

    $data["mutasi"] = $this->mutasi_model->get_mutasi();
    $data["nama_penjaga"] = $this->mutasi_model->get_nama_piket();
        // $this->load->view("superadmin/mutasi/pdf", $data);
    
        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model

        // $data['mutasi'] = $mutasi;

    ob_start();
    if($this->session->userdata('akses')=='1'){
        
        $this->load->view('superadmin/mutasi/pdf', $data);
        
    }else{
        echo "Anda tidak berhak mengakses halaman ini";
    }   
    
    
    $html = ob_get_contents();
    ob_end_clean();

    require_once('./assets/html2pdf/html2pdf.class.php');
    $pdf = new HTML2PDF('P','A4','en');
    $pdf->WriteHTML($html);
    $pdf->Output('Data Mutasi.pdf', 'D');
}
/*public function cetak_temp()
{

        // $this->load->view("superadmin/mutasi/pdf", $data);
  
        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model

        // $data['mutasi'] = $mutasi;

    $data["mutasi"] = $this->mutasi_model->get_mutasi();
    $data["nama_penjaga"] = $this->mutasi_model->get_nama_piket();
        // $this->load->view("superadmin/mutasi/pdf", $data);
    
        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model

        // $data['mutasi'] = $mutasi;

    ob_start();
    if($this->session->userdata('akses')=='1'){
        
     $this->load->view('superadmin/mutasi/pdf', $data);
     
 }else{
    echo "Anda tidak berhak mengakses halaman ini";
}


$html = ob_get_contents();
ob_end_clean();

require_once('./assets/html2pdf/html2pdf.class.php');
$pdf = new HTML2PDF('P','A4','en');
$pdf->WriteHTML($html);
$pdf->Output('Data Mutasi.pdf', 'D');
}*/

 public function cetak_temp($nama_petugas='')
{

        // $this->load->view("admin/mutasi/pdf", $data);

        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model

        // $data['mutasi'] = $mutasi;

    $data["mutasi"] = $this->mutasi_model->list_mutasi_by_nama($nama_petugas);
    $data["nama_penjaga"] = $this->mutasi_model->list_mutasi_personil($nama_petugas);
        // $this->load->view("admin/mutasi/pdf", $data);
    
        // $mutasi = $this->mutasi_model->view_all(); // Panggil fungsi view_all yang ada di mutasi_model

        // $data['mutasi'] = $mutasi;

    ob_start();
    if($this->session->userdata('akses')=='1'){

       $this->load->view('personil/mutasi/pdf', $data);
   }else{
    echo "Anda tidak berhak mengakses halaman ini";
}

$html = ob_get_contents();
ob_end_clean();

require_once('./assets/html2pdf/html2pdf.class.php');
$pdf = new HTML2PDF('P','A4','en');
$pdf->WriteHTML($html);
$pdf->Output('Data Mutasi.pdf', 'D');
}

public function print()
{
    $data["mutasi"] = $this->mutasi_model->get_mutasi();
    $data["nama_penjaga"] = $this->mutasi_model->get_nama_piket();
    if($this->session->userdata('akses')=='1'){
        
      $this->load->view("superadmin/mutasi/print", $data);
      
  }else{
    echo "Anda tidak berhak mengakses halaman ini";
}

}
public function print_temp($nama_petugas='')
{
    $data["mutasi"] = $this->mutasi_model->list_mutasi_by_nama($nama_petugas);
    $data["nama_penjaga"] = $this->mutasi_model->list_mutasi_personil($nama_petugas);
    if($this->session->userdata('akses')=='1'){
        
      $this->load->view("superadmin/mutasi/print", $data);
      
  }else{
    echo "Anda tidak berhak mengakses halaman ini";
}

}


    // public function indexby()
    // {
    //     // $departemen = $this->session->userdata['ses_dept'];
    //     $data["Mutasi"] = $this->mutasi_model->get_mutasi($departemen);
    //     $this->load->view("superadmin/mutasi/list", $data);
    // }



public function add()
{
    $data["nama_penjaga"] = $this->mutasi_model->get_nama_piket();
    $data['opt_nama'] = $this->mutasi_model->get_opt_nama();
    $mutasi = $this->mutasi_model;
    $validation = $this->form_validation;
    $validation->set_rules($mutasi->rules());        
    
    if ($validation->run()) {
        $mutasi->save();
        $this->session->set_flashdata('success', 'Berhasil disimpan');
    }
    if($this->session->userdata('akses')=='1'){
        
     $this->load->view("superadmin/mutasi/new_form",$data);
     
 }else{
    echo "Anda tidak berhak mengakses halaman ini";
}



}

public function add_piket()
{
    
    $data['idunik']=$this->mutasi_model->get_no_invoice();
    $data['opt_nama'] = $this->mutasi_model->get_opt_nama();

    $mutasi = $this->mutasi_model;
    $validation = $this->form_validation;
    $validation->set_rules($mutasi->rules2());        
    
    if ($validation->run()) {
        $mutasi->savePiket();
            // $mutasi->savePersonil();
        $this->session->set_flashdata('success', 'Berhasil disimpan');
    }
    if($this->session->userdata('akses')=='1'){
        
     $this->load->view("superadmin/mutasi/add_piket",$data);
     
 }else{
    echo "Anda tidak berhak mengakses halaman ini";
}




}

public function edit($id = null)
{

    if (!isset($id)) redirect('superadmin/mutasi');
    
    $mutasi = $this->mutasi_model;
    $validation = $this->form_validation;
    $validation->set_rules($mutasi->rules());

    if ($validation->run()) {
        $mutasi->update();
        $this->session->set_flashdata('success', 'Berhasil disimpan');
    }

    $data["mutasi"] = $mutasi->getById($id);
    if (!$data["mutasi"]) show_404();
    $data['opt_nama'] = $this->mutasi_model->get_opt_nama();    
    if($this->session->userdata('akses')=='1'){
        
     $this->load->view("superadmin/mutasi/edit_form", $data);
     
 }else{
    echo "Anda tidak berhak mengakses halaman ini";
}    

}

public function editPiket($id = null)
{

    if (!isset($id)) redirect('superadmin/mutasi');
    
    $mutasi = $this->mutasi_model;
    $validation = $this->form_validation;
    $validation->set_rules($mutasi->rules2());

    if ($validation->run()) {
        $mutasi->updatePiket();
        $this->session->set_flashdata('success', 'Berhasil disimpan');
    }

    $data["mutasi"] = $mutasi->getByIdPiket($id);
    if (!$data["mutasi"]) show_404();
    $data['opt_nama'] = $this->mutasi_model->get_opt_nama();  
    if($this->session->userdata('akses')=='1'){
        
     $this->load->view("superadmin/mutasi/edit_form_piket", $data);
     
 }else{
    echo "Anda tidak berhak mengakses halaman ini";
}         

}

public function delete($id=null)
{
    if (!isset($id)) show_404();
    
    if ($this->mutasi_model->delete($id)) {
        redirect(site_url('superadmin/mutasi'));
    }
}
}