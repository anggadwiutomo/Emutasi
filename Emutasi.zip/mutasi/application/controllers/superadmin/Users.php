<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("user_model");
        $this->load->library('form_validation');
    }

    public function index()
    {

        $data["users"] = $this->user_model->getDetail();
        if($this->session->userdata('akses')=='1'){
            $this->load->view("superadmin/user/list", $data);
        }else{
            echo "Anda tidak berhak mengakses halaman ini";
        }

    }

    public function add()
    {

        $user = $this->user_model;
        $validation = $this->form_validation;
        $validation->set_rules($user->rules());

        if ($validation->run()) {
            $user->save();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
            redirect('/superadmin/users','refresh');
        }

        $data['opt_dept'] = $this->user_model->getDepartemen();
        $data['opt_pangkat'] = $this->user_model->getPangkat();
        if($this->session->userdata('akses')=='1'){

          $this->load->view("superadmin/user/add_user",$data);
      }else{
        echo "Anda tidak berhak mengakses halaman ini";
    } 


}

public function edit($id = null)
{
    if (!isset($id)) redirect('superadmin/user');

    $user = $this->user_model;
    $validation = $this->form_validation;
    $validation->set_rules($user->rules());

    if ($validation->run()) {
        $user->update();
        $this->session->set_flashdata('success', 'Berhasil disimpan');
        redirect('/superadmin/users','refresh');
    }

    $data["user"] = $user->getById($id);
    if (!$data["user"]) show_404();
    $data['opt_dept'] = $this->user_model->getDepartemen();
    $data['opt_pangkat'] = $this->user_model->getPangkat(); 
    
    if($this->session->userdata('akses')=='1'){
        $this->load->view("superadmin/user/edit_form", $data);
    }else{
        echo "Anda tidak berhak mengakses halaman ini";
    }       

}

public function delete($id=null)
{
    if (!isset($id)) show_404();

    if ($this->user_model->delete($id)) {
        redirect(site_url('superadmin/users'));
    }
}
}