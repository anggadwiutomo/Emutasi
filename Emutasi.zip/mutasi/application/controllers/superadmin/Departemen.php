<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Departemen extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model("departemen_model");
		$this->load->library('form_validation');
	}
	
	// List all your items
	public function index()
	{
		//$data["departemen"] = $this->departemen_model->getAll();
		$data['departemen'] = $this->departemen_model->view();
		
		if($this->session->userdata('akses')=='1'){
			
			$this->load->view("superadmin/departemen/list",$data);
			
		}else{
			echo "Anda tidak berhak mengakses halaman ini";
		}	

	}
	// public function kode()
	// {
	// 	$data['kodeunik'] = $this->departemen_model->code_otomatis();
	// 	$this->load->view("superadmin/departemen/add_departemen",$data);
	// }
	
		// Add a new item
	public function add()
	{
		$data['kodeunik']=$this->departemen_model->buat_kode();
		$departemen = $this->departemen_model;
		$validation = $this->form_validation;
		$validation->set_rules($departemen->rules());

		if ($validation->run()) {
			$departemen->save();
			$this->session->set_flashdata('success', 'Berhasil disimpan');
			redirect($this->uri->uri_string());

		}
		if($this->session->userdata('akses')=='1'){
			$this->load->view("superadmin/departemen/add_departemen",$data);
		}else{
			echo "Anda tidak berhak mengakses halaman ini";
		}	
		
	}
	
		//Update one item
	public function edit( $id = NULL )
	{
		if (!isset($id)) redirect('superadmin/departemen');

		$departemen = $this->departemen_model;
		$validation = $this->form_validation;
		$validation->set_rules($departemen->rules());

		if ($validation->run()) {
			$departemen->update();
			$this->session->set_flashdata('success', 'Berhasil disimpan');
		}

		$data["departemen"] = $departemen->getById($id);
		if (!$data["departemen"]) show_404();
		if($this->session->userdata('akses')=='1'){
			$this->load->view("superadmin/departemen/edit_form",$data);
		}else{
			echo "Anda tidak berhak mengakses halaman ini";
		}	       
		
	}
	
		//Delete one item
	public function delete( $id = NULL )
	{
		if (!isset($id)) show_404();
		
		if ($this->departemen_model->delete($id)) {
			redirect(site_url('superadmin/departemen/'));
		}
	}


	/////Cabang Departemen
	// Add a new item
	public function add_cabang()
	{
		$data['kodeunik_cabang']=$this->departemen_model->buat_kode_cabang();
		$departemen = $this->departemen_model;
		$validation = $this->form_validation;
		$validation->set_rules($departemen->rules_cabang());
		$data['opt_dept'] = $this->departemen_model->getDepartemen();

		if ($validation->run()) {
			$departemen->save_cabang();
			$this->session->set_flashdata('success', 'Berhasil disimpan');
			redirect($this->uri->uri_string());

		}
		if($this->session->userdata('akses')=='1'){
			$this->load->view("superadmin/departemen/add_departemen_cabang",$data);
		}else{
			echo "Anda tidak berhak mengakses halaman ini";
		}	
		
	}
	
		//Update one item
	public function edit_cabang( $id = NULL )
	{
		if (!isset($id)) redirect('superadmin/departemen');

		$departemen = $this->departemen_model;
		$validation = $this->form_validation;
		$validation->set_rules($departemen->rules_cabang());

		if ($validation->run()) {
			$departemen->update();
			$this->session->set_flashdata('success', 'Berhasil disimpan');
		}

		$data['opt_dept'] = $this->departemen_model->getDepartemen();
		$data["departemen"] = $departemen->getById($id);
		if (!$data["departemen"]) show_404();
		if($this->session->userdata('akses')=='1'){
			$this->load->view("superadmin/departemen/edit_form_cabang",$data);
		}else{
			echo "Anda tidak berhak mengakses halaman ini";
		}	       
		
	}
	
		//Delete one item
	public function delete_cabang( $id = NULL )
	{
		if (!isset($id)) show_404();
		
		if ($this->departemen_model->delete($id)) {
			redirect(site_url('superadmin/departemen/'));
		}
	}


	///////Chained Dropdown
	public function listDepartemenCabang(){
		// Ambil data ID Cabang yang dikirim via ajax post
		$dept_id = $this->input->post('dept_id');
		
		$dept_cabang = $this->departemen_model->viewByDepartemen($dept_id);
		
		// Buat variabel untuk menampung tag-tag option nya
		// Set defaultnya dengan tag option Pilih
		$lists = "<option value=''>Pilih</option>";
		
		foreach($dept_cabang as $data){
			$lists .= "<option value='".$data->dept_cabang_id."'>".$data->nama_dept_cabang."</option>"; // Tambahkan tag option ke variabel $lists
		}
		
		$callback = array('list_dept_cabang'=>$lists); // Masukan variabel lists tadi ke dalam array $callback dengan index array : list_kota

		echo json_encode($callback); // konversi varibael $callback menjadi JSON
	}
}

/* End of file Departemen.php */
/* Location: ./application/controllers/Departemen.php */


