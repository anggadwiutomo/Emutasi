<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Personil extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("personil_model");
        $this->load->library('form_validation');
    }

    public function index()
    {
        // $data["personil"] = $this->personil_model->getAll();
        $data["pangkat"] = $this->personil_model->get_detail();
        if($this->session->userdata('akses')=='1'){
            
          $this->load->view("superadmin/personil/list", $data);
          
      }else{
        echo "Anda tidak berhak mengakses halaman ini";
    } 
    
    

}

public function get_personil_by_dept($dept_id='')
//write this way so that you can call the url like
//localhost/norwin/list_group/get_product_by_group
{

        if($dept_id)//no need to check uri->segment
        {
            $this->load->database();                    
            $data['product_data'] = $this->personil_model->list_personil_by_dept($dept_id);
            $data["pangkat"] = $this->personil_model->get_detail();
            if($this->session->userdata('akses')=='1'){
                
             $this->load->view('superadmin/personil/list', $data);
             
         }else{
            echo "Anda tidak berhak mengakses halaman ini";
        } 
        

    }
    else
    {
        redirect('superadmin/departemen/list');
    }

}
public function add()
{
    $personil = $this->personil_model;
    $validation = $this->form_validation;
    $validation->set_rules($personil->rules());
    
    if ($validation->run()) {
        $personil->save();
        $this->session->set_flashdata('success', 'Berhasil disimpan');
    }
    
    $data['opt_pangkat'] = $this->personil_model->get_opt_pangkat();
    if($this->session->userdata('akses')=='1'){
        
      $this->load->view("superadmin/personil/add_personil",$data);
      
  }else{
    echo "Anda tidak berhak mengakses halaman ini";
} 

}

public function edit($id = null)
{
    if (!isset($id)) redirect('superadmin/personil');
    
    $personil = $this->personil_model;
    $validation = $this->form_validation;
    $validation->set_rules($personil->rules());

    if ($validation->run()) {
        $personil->update();
        $this->session->set_flashdata('success', 'Berhasil disimpan');
    }

    $data["personil"] = $personil->getById($id);
    if (!$data["personil"]) show_404();
    $data['opt_pangkat'] = $this->personil_model->get_opt_pangkat();
    if($this->session->userdata('akses')=='1'){
        
      $this->load->view("superadmin/personil/edit_form", $data);
      
  }else{
    echo "Anda tidak berhak mengakses halaman ini";
} 

}

public function delete($id=null)
{
    if (!isset($id)) show_404();
    
    if ($this->personil_model->delete($id)) {
        redirect(site_url('superadmin/personil'));
    }
}
    ///Reset Password

    // public function changePassword()
    // {
        
    //     $data['title'] = 'Change Password';

    //     $this->load->library('form_validation');

    //     $this->form_validation->set_rules('oldpass', 'old password', 'callback_password_check');
    //     $this->form_validation->set_rules('newpass', 'new password', 'required');
    //     $this->form_validation->set_rules('passconf', 'confirm password', 'required|matches[newpass]');

    //     $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

    //     if($this->form_validation->run() == false) {
    //         //$this->load->view('header', $data);
    //          if($this->session->userdata('akses')=='1'){
    //     $this->load->view('superadmin/setting', $data);
    // }else{
    //     echo "Anda tidak berhak mengakses halaman ini";
    // }
            
    //         //$this->load->view('footer', $data);
    //     }
    //     else {

    //         $id = $this->session->userdata('ses_nrp');

    //         $newpass = $this->input->post('newpass');

    //         $this->personil_model->update_user1($id, array('pass' => md5($newpass)));
    //         echo "<script> alert('Password Berhasil Diganti , Harap Login Kembali'); 
    //         window.location.href='keluar';
    //         </script>";
    //     //     echo "<script> alert('Sukses , Harap Login Kembali'); </script>";
    //     //     $this->session->sess_destroy();
    //     //     $url=base_url('');
    //     // redirect($url);
    //       // redirect('login');
    //     }
    // }

    // public function password_check($oldpass)
    // {
    //     $id = $this->session->userdata('ses_nrp');
    //     $user = $this->personil_model->get_user1($id);

    //     if($user->pass !== md5($oldpass)) {
    //         $this->form_validation->set_message('password_check', 'The {field} does not match');
    //         return false;
    //     }

    //     return true;
    // }

    //  public function keluar($id=null){
    //     redirect('login', 'refresh');
    // }
}