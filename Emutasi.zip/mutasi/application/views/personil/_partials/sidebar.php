<!-- Sidebar -->
<?php  if($this->session->userdata('masuk') != TRUE){
    $url=base_url();
    redirect($url);
}
?>


<!--Akses Menu Untuk Mahasiswa-->

    <ul class="sidebar navbar-nav">
    <li class="nav-item <?php echo $this->uri->segment(2) == '' ? 'active': '' ?>">
        <a class="nav-link" href="<?php echo site_url('personil') ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
   
    <li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'mutasi' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
        aria-expanded="false">
        <i class="fas fa-fw fa-book"></i>
        <span>Buku Mutasi</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <h6 class="dropdown-header">Petugas Piket:</h6>
        <a class="dropdown-item" href="<?php echo site_url('personil/mutasi/nama_petugas') ?>">Nama Petugas</a>
        <div class="dropdown-divider"></div>
        <h6 class="dropdown-header">Buku Mutasi:</h6>
        <a class="dropdown-item" href="<?php echo site_url('personil/mutasi/add') ?>">Input Mutasi</a>
        <a class="dropdown-item" href="<?php echo site_url('personil/mutasi') ?>">Mutasi Hari ini</a>

    </div>
</li>
<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'personil' ? 'active' : '' ?>">
    <a class="nav-link" href="<?php echo site_url('personil/personil') ?>">
        <i class="fas fa-fw fa-users"></i>
        <span>Personil</span>
    </a>

</li>


<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'settings' ? 'active' : '' ?>">
  <a class="nav-link" href="<?php echo site_url('personil/settings') ?>">
    <i class="fas fa-fw fa-cog"></i>
    <span>Settings</span>
</a>
<!-- <div class="dropdown-menu" aria-labelledby="pagesDropdown">
    <h6 class="dropdown-header">Login Screens:</h6>

    <a class="dropdown-item" href="<?php echo site_url('personil/personil/edit/') ?>">Login</a>
    <a class="dropdown-item" href="register.html">Register</a>
    <a class="dropdown-item" href="forgot-password.html">Forgot Password</a>
    <div class="dropdown-divider"></div>
    <h6 class="dropdown-header">Other Pages:</h6>
    <a class="dropdown-item" href="404.html">404 Page</a>
    <a class="dropdown-item" href="blank.html">Blank Page</a>
</div> -->
</li>
</ul>
