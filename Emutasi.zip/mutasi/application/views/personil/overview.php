
<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view("personil/_partials/head.php") ?>
</head>
<body id="page-top">
	

<?php $this->load->view("personil/_partials/navbar.php") ?>

<div id="wrapper">

	<?php $this->load->view("personil/_partials/sidebar.php") ?>

	<div id="content-wrapper">

		<div class="container-fluid">

        <!-- 
        karena ini halaman overview (home), kita matikan partial breadcrumb.
        Jika anda ingin mengampilkan breadcrumb di halaman overview,
        silahkan hilangkan komentar (//) di tag PHP di bawah.
        -->
		<?php //$this->load->view("personil/_partials/breadcrumb.php") ?>

		<!-- DataTables -->
							<div class="card mb-3">
								<div class="card-header">
									<!-- <a href="<?php echo site_url('personil/mutasi/add') ?>"><i class="fas fa-plus"></i> Add New</a> -->
									<h5>Riwayat Buku Mutasi </h5>
								</div>
								<div class="card-body">

									<div class="table-responsive">
										<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
											<thead>
												<tr>
													<th width="10">No.</th>
													<th width="400">Hari / Tanggal</th>
													<th width="200">Mutasi</th>													
													<th width="200">Print</th>
													<th width="200">Status</th>

												</tr>
											</thead>
											<tbody>
												<?php $no = 1;?>
												<?php foreach ($mutasi as $mutasi): ?>
													<tr>
														<td>
															<?php echo $no ?>
														</td>
														<td width="150">
															<?php echo tanggal_indo($mutasi->tgl) ?>
														</td>
														<td>
															<a href="<?php echo site_url('personil/mutasi/get_mutasi_by_nama/'. $mutasi->id) ?>"
											 class="btn btn-small"><i class="fas fa-book"></i> Lihat Detail</a>
														</td>

														<td width="250">
															<a target="BLANK" href="<?php echo site_url('personil/mutasi/print_temp/'.$mutasi->id) ?>"
																class="btn btn-small"><i class="fas fa-print"></i> Print</a>
																|
															<a target="BLANK" href="<?php echo site_url('personil/mutasi/cetak_temp/'.$mutasi->id) ?>"
																class="btn btn-small"><i class="fas fa-cloud-download-alt"></i> PDF</a>


																</td>
																<td>
																	<?php 
																	if($mutasi->status==0){
																		echo "<button type='button' class='btn btn-warning'>Belum dikonfirmasi</button>";

																	}else{
																		echo "<button type='button' class='btn btn-success'>Telah dikonfirmasi</button>";
																	
																	}
																	?>
																</td>
															</tr>
															<?php $no++;?>
														<?php endforeach; ?>
													</tbody>
												</table>
											</div>
										</div>
									</div>


		<!-- Area Chart Example-->
		<!-- /.container-fluid -->

		<!-- Sticky Footer -->
		<?php $this->load->view("personil/_partials/footer.php") ?>

	</div>
	<!-- /.content-wrapper -->

</div>
<!-- /#wrapper -->


<?php $this->load->view("personil/_partials/scrolltop.php") ?>
<?php $this->load->view("personil/_partials/modal.php") ?>
<?php $this->load->view("personil/_partials/js.php") ?>
    
</body>
</html>
	