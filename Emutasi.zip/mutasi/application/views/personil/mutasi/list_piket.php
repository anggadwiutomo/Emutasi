<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("personil/_partials/head.php") ?>
</head>

<body id="page-top">

	<?php $this->load->view("personil/_partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("personil/_partials/sidebar.php") ?>

		<div id="content-wrapper">

			<div class="container-fluid">

				<?php $this->load->view("personil/_partials/breadcrumb.php") ?>
				<?php if ($this->session->flashdata('success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo $this->session->flashdata('success'); ?>
				</div>
				<?php endif; ?>


				<!-- DataTables -->

					<div class="card mb-3">
						<div class="card-header">
							<div style="padding-left: 10px" class="accordion float-right" id="accordionExample">
								<?php foreach ($nama_penjaga as $m):
							$var= $m->id ;										

						endforeach;
						if(isset($var)==0){
							?>
							<a href="<?php echo site_url('personil/mutasi/add_piket') ?>"><button class="btn btn-primary btn-sm" ><i class="fas fa-plus"></i> Tambah Petugas Piket</button></div></a>
							<?php 
						}else{
							?>
							<a href="<?php echo site_url('personil/mutasi/editPiket/'.$m->id) ?>"><button class="btn btn-primary btn-sm" ><i class="fas fa-edit"></i> Edit Petugas Piket</button></div></a>
							<?php }
							

							?>							
							<?php 
							foreach ($nama_penjaga as $m):
								$var= $m->id ;
								$date= $m->tgl;										

							endforeach;	

							?>
							<h5>Petugas Piket</h5>

						</div>
						<div class="card-body">

							<div class="table-responsive">
								<table class="table table-bordered" width="100%" cellspacing="0">
									<thead>
										<tr>
											<th width="50">No.</th>
											<th width="400">NRP</th>
											<th width="600">Nama Petugas</th>
											<th width="100">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php $no = 1; ?>
										<?php 
										foreach ($nama_penjaga as $m):
											$var= $m->nrp_personil ;										
										endforeach;
										?>
										<?php
										if(isset($var)){
											$sql ="SELECT * FROM personil where nrp in ($var)";
											$query = $this->db->query($sql);
											if ($query->num_rows() > 0) {
												foreach ($query->result() as $row) {
													?>
													<tr>
														<td><?php echo $no;?></td>
														<td><?php echo $row->nrp; ?></td>
														<td><?php echo $row->nama; ?></td>
														<td width="250">
															<a href="<?php echo site_url('personil/mutasi/editPiket/'.$m->id) ?>"
																class="btn btn-small"><i class="fas fa-edit"></i> Edit</a>
															</td>
														</tr>
														<?php $no++;?>
													<?php }}} ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>



				<!-- DataTables -->

					<div class="card mb-3">
						<div class="card-header">
								<h5>Nama Penerima</h5>
						</div>
						<div class="card-body">

							<div class="table-responsive">
								<table class="table table-bordered" width="100%" cellspacing="0">
									<thead>
										<tr>
											<th width="50">No.</th>
											<th width="400">NRP</th>
											<th width="600">Nama Petugas</th>
											<th width="100">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php $no = 1; ?>
										<?php
										if(isset($date)){
										$sql ="SELECT * FROM mutasi_personil INNER JOIN personil ON mutasi_personil.nrp_penerima=personil.nrp where mutasi_personil.tgl='$date' ";
											$query = $this->db->query($sql);
											if ($query->num_rows() > 0) {
												foreach ($query->result() as $row) {
													?>
													<tr>
														<td><?php echo $no;?></td>
														<td><?php echo $row->nrp; ?></td>
														<td><?php echo $row->nama; ?></td>
														<td width="250">
															<a href="<?php echo site_url('personil/mutasi/editPiket/'.$m->id) ?>"
																class="btn btn-small"><i class="fas fa-edit"></i> Edit</a>
															</td>
														</tr>
														<?php $no++;?>
													<?php }}} ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>

												<!-- DataTables -->

					<div class="card mb-3">
						<div class="card-header">
							<h5>Mengetahui Pelaksana</h5>

						</div>
						<div class="card-body">

							<div class="table-responsive">
								<table class="table table-bordered" width="100%" cellspacing="0">
									<thead>
										<tr>
											<th width="50">No.</th>
											<th width="400">NRP</th>
											<th width="600">Nama Petugas</th>
											<th width="100">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php $no = 1; ?>
										
										<?php
										if(isset($date)){
											$sql ="SELECT * FROM mutasi_personil INNER JOIN user ON mutasi_personil.nrp_pelaksana=user.nrp where mutasi_personil.tgl='$date' ";
											$query = $this->db->query($sql);
											if ($query->num_rows() > 0) {
												foreach ($query->result() as $row) {
													?>
													<tr>
														<td><?php echo $no;?></td>
														<td><?php echo $row->nrp; ?></td>
														<td><?php echo $row->nama; ?></td>
														<td width="250">
															<a href="<?php echo site_url('personil/mutasi/editPiket/'.$m->id) ?>"
																class="btn btn-small"><i class="fas fa-edit"></i> Edit</a>
															</td>
														</tr>
														<?php $no++;?>
													<?php }}} ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>



							</div>



								</div>
								<!-- /.container-fluid -->

								<!-- Sticky Footer -->
								<?php $this->load->view("personil/_partials/footer.php") ?>

							</div>
							<!-- /.content-wrapper -->

						</div>
						<!-- /#wrapper -->


						<?php $this->load->view("personil/_partials/scrolltop.php") ?>
						<?php $this->load->view("personil/_partials/modal.php") ?>

						<?php $this->load->view("personil/_partials/js.php") ?>
						<script>
							function deleteConfirm(url){
								$('#btn-delete').attr('href', url);
								$('#deleteModal').modal();
							}

						</script>
					</body>


					</html>