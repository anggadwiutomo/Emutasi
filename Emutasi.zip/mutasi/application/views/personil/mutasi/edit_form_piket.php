<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("personil/_partials/head.php") ?>
</head>

<body id="page-top">

	<?php $this->load->view("personil/_partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("personil/_partials/sidebar.php") ?>

		<div id="content-wrapper">

			<div class="container-fluid">

				<?php $this->load->view("personil/_partials/breadcrumb.php") ?>

				<?php if ($this->session->flashdata('success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo $this->session->flashdata('success'); ?>
				</div>
				<?php endif; ?>

				<!-- Card  -->
				<div class="card mb-3">
					<div class="card-header">

						<a href="<?php echo site_url('personil/mutasi/') ?>"><i class="fas fa-arrow-left"></i>
							Back</a>
					</div>
					<div class="card-body">

						<form action="<?php base_url('personil/mutasi/edit') ?>" method="post" enctype="multipart/form-data">

							<input type="hidden" name="id" value="<?php echo $mutasi->id?>" />

							<div class="form-group">
								<label for="tanggal">ID Piket*</label>
								<input class="form-control <?php echo form_error('tanggal') ? 'is-invalid':'' ?>"
								 type="" name="tanggal" readonly="readonly"	 value="<?php echo $mutasi->id ?>" />
								<div class="invalid-feedback">
									<?php echo form_error('tanggal') ?>
								</div>
							</div>

<!-- 							<div class="form-group">
								<label for="nama_petugas">Nama Petugas*</label>
								<input class="form-control <?php echo form_error('price') ? 'is-invalid':'' ?>"
								 type="text" name="nama_petugas" placeholder="mutasi price" value="<?php echo $mutasi->nama_petugas ?>" />
								<div class="invalid-feedback">
									<?php echo form_error('nama_petugas') ?>
								</div>
							</div>
 -->
 		<div class="form-group">

	    <label for="name">Nama Petugas Piket*</label>
	    
	        <select required name="nama_petugas[]" id="nama_petugas" class="form-control" multiple>
	        	<option value="" disabled diselected>-- Pilih Petugas --</option>
	        	<?php
	        	$var = $mutasi->nrp_personil;
	        	$pieces = explode(",", $var);
				// foreach($pieces as $element){
				// 		$element;
					?>	

	        <?php
	        foreach ($opt_nama as $row) {
	        	foreach($pieces as $element){
	        		if($row->nrp==$element){
	        			echo "<option value='".$row->nrp."' selected>".$row->nrp." - ".$row->nama."</option>";
	        			goto skip;
	        		}
				  }
				  	echo "<option value='".$row->nrp."'>".$row->nrp." - ".$row->nama."</option>";
					skip:
				}
			  echo"
			</select>"
			?>
		</div>




		<div class="form-group">

	    <label for="name">Mengetahui Pelaksana*</label>
	    
	        <select required name="nama_pelaksana" id="nama_pelaksana" class="form-control" >
	        	<option value="" disabled diselected>-- Pilih Petugas --</option>
	        <?php                                
	        foreach ($opt_admin as $row) {  
	        	if($row->nrp==$mutasi->nrp_pelaksana){
			  echo "<option selected value='".$row->nrp."'>".$row->nrp." - ".$row->nama."</option>";
			  }else{
			  	echo "<option value='".$row->nrp."'>".$row->nrp." - ".$row->nama."</option>";
			  }
			  }
			  echo"
			</select>"
			?>
		</div>

				  <div class="form-group">

	    <label for="name">Nama Penerima Piket Selanjutnya*</label>
	    
	        <select required name="nama_penerima" id="nama_penerima" class="form-control" >
	        	<option value="" disabled diselected>-- Pilih Petugas --</option>
	        <?php                                
	        foreach ($opt_nama as $row) {  
	        	if($row->nrp==$mutasi->nrp_penerima){
			  echo "<option selected value='".$row->nrp."'>".$row->nrp." - ".$row->nama."</option>";
			  }else{
			  	echo "<option value='".$row->nrp."'>".$row->nrp." - ".$row->nama."</option>";
			  }
			}
			  echo"
			</select>"
			?>
		</div>






							<input class="btn btn-success" type="submit" name="btn" value="Save" />
						</form>

					</div>

					<div class="card-footer small text-muted">
						* required fields
					</div>


				</div>
				<!-- /.container-fluid -->

				<!-- Sticky Footer -->
				<?php $this->load->view("personil/_partials/footer.php") ?>

			</div>
			<!-- /.content-wrapper -->

		</div>
		<!-- /#wrapper -->

		<?php $this->load->view("personil/_partials/scrolltop.php") ?>
		<?php $this->load->view("personil/_partials/modal.php") ?>
		<?php $this->load->view("personil/_partials/js.php") ?>

</body>
<script>
// $(document).ready(function() {
// 	var max_fields      = 10; //maximum input boxes allowed
// 	var wrapper   		= $(".input_fields_wrap"); //Fields wrapper
// 	var add_button      = $(".add_field_button"); //Add button ID
	
// 	var x = 1; //initlal text box count
// 	$(add_button).click(function(e){ //on add input button click
// 		e.preventDefault();
// 		if(x < max_fields){ //max input box allowed
// 			x++; //text box increment
// 			$(wrapper).append('<div><input type="text" name="mytext[]"/><a href="#" class="remove_field">Remove</a></div>'); //add input box
// 		}
// 	});
	
// 	$(wrapper).on("click",".remove_field", function(e){ //user click on remove text
// 		e.preventDefault(); $(this).parent('div').remove(); x--;
// 	})
// });

$(".js-example-tokenizer").select2({
    tags: true,
    tokenSeparators: [',', ' ']
})

$('select').select2({
  createTag: function (params) {
    var term = $.trim(params.term);

    if (term === '') {
      return null;
    }

    return {
      id: term,
      text: term,
      newTag: true // add additional parameters
    }
  }
});

$('select').select2({
  createTag: function (params) {
    // Don't offset to create a tag if there is no @ symbol
    if (params.term.indexOf('@') === -1) {
      // Return null to disable tag creation
      return null;
    }

    return {
      id: params.term,
      text: params.term
    }
  }
});
$('select').select2({
  insertTag: function (data, tag) {
    // Insert the tag at the end of the results
    data.push(tag);
  }
});
</script>

</html>