<!DOCTYPE html>
<html>
<style >
 body{
    background-image: url("assets/image/bg.jpg");
    background-repeat: no-repeat;
    background-position: center; /* Center the image */
    background-size: cover; /* Resize the background image to cover the entire container */   

}
</style>
<head>
  <title>Sign In</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Bootstrap -->
  <link href="<?php echo base_url().'assets/bootstrap/css/bootstrap.css'?>" rel="stylesheet">
</head>
<body class="bg-danger">
  <div class="container">
    <div><br><br><br><br><br></div>
      <div class="card card-login mx-auto mt-5">
        <div><br></div>
        <center><img style="width: 360px" src="<?php echo base_url()?>assets/image/kopakpol.png"></center> 
        <br>
      <div class="card-header">Silahkan Masukkan NRP dan Password</div>
      <div class="card-body">
        <form class="form-signin" action="<?php echo base_url().'index.php/login/auth'?>" method="post">
          <?php echo $this->session->flashdata('msg');?>
          <div class="form-group">
            <div class="form-label-group">

              <input type="text" id="username" name="username" class="form-control" placeholder="Username" required autofocus>
              <label for="username" >NRP</label>


            </div>
          </div>
          <div class="form-group">
            <div class="form-label-group">

              <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
              <label for="password" >Password</label>

            </div>
          </div>
          <button class="btn btn-lg btn-primary btn-block" type="submit">Login</button>
        </form>
      </div>
    </div> <!-- /container -->

    <!-- jQuery-->
    <script src="<?php echo base_url().'assets/bootstrap/js/jquery.js'?>"></script>
    <!-- Bootsrap -->
    <script src="<?php echo base_url().'assets/bootstrap/js/bootstrap.min.js'?>"></script>

  </body>
  </html>

  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url().'assets/bootstrap/css/bootstrap.min.css'?>" rel="stylesheet">

  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url().'assets/fontawesome-free/css/all.min.css'?>" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="<?php echo base_url().'css/sb-admin.css'?>" rel="stylesheet">

  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url('assets/jquery/jquery.min.js') ?>"></script>
  <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?php echo base_url('assets/jquery-easing/jquery.easing.min.js')?>"></script>

</body>

</html>
