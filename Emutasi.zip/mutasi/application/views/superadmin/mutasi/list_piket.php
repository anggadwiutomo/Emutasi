<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>

<body id="page-top">

	<?php $this->load->view("admin/_partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("admin/_partials/sidebar.php") ?>

		<div id="content-wrapper">

			<div class="container-fluid">

				<?php $this->load->view("admin/_partials/breadcrumb.php") ?>

				<!-- DataTables -->
				<div class="card mb-3">
					<div class="card-header">
						<a href="<?php echo site_url('admin/mutasi/add_piket') ?>"><i class="fas fa-plus"></i> Add New</a>
						<!-- <input type="button" value="Print this page" onclick="window.print()"> -->
						<a target="_BLANK" class="btn btn-primary btn-block margin-bottom" href="<?php echo base_url()?>index.php/admin/mutasi/print"><i class="fa fa-print"></i> Cetak</a>
						<a target="_BLANK" class="btn btn-primary btn-block margin-bottom" href="<?php echo $url_cetak; ?>"><i class="fa fa-print"></i> Download</a>

					</div>
					<div class="card-body">
<div class="row">
     <div class="input-daterange">
      <div class="col-md-4">
       <input type="text" name="start_date" id="start_date" class="form-control" />
      </div>
      <div class="col-md-4">
       <input type="text" name="end_date" id="end_date" class="form-control" />
      </div>      
     </div>
     <div class="col-md-4">
      <input type="button" name="search" id="search" value="Search" class="btn btn-info" />
     </div>
    </div>
						<div class="table-responsive">
							<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
								<thead>
									<tr>
										<th width="50">No.</th>
										<th>NRP</th>
										<th>Nama Petugas</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php $no = 1; ?>
									<?php 
										foreach ($nama_penjaga as $m):
										$var= $m->nrp_personil ;										
											
										endforeach;
									
										// $pieces = explode(",", $var);
										// foreach($pieces as $element):	
									?>
	           						<?php
	        						// $this->db->from('personil');
									// $query = $this->db->get();
	           						// $isDefined = isset($var);
									if(isset($var)){
	           						$sql ="SELECT * FROM personil where nrp in ($var)";
									$query = $this->db->query($sql);
									if ($query->num_rows() > 0) {
										foreach ($query->result() as $row) {
	           						?>
	        						<tr>
										<td width="50"><?php echo $no;?></td>
										<td width="400"><?php echo $row->nrp; ?></td>
										<td width="600"><?php echo $row->nama_personil; ?></td>
										<td width="100">
											<a href="<?php echo site_url('admin/mutasi/editPiket/'.$m->id) ?>"
											 class="btn btn-small"><i class="fas fa-edit"></i> Edit</a>
										</td>
									</tr>
									<?php $no++;?>
									<?php }}} ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>


			</div>
			<!-- /.container-fluid -->

			<!-- Sticky Footer -->
			<?php $this->load->view("admin/_partials/footer.php") ?>

		</div>
		<!-- /.content-wrapper -->

	</div>
	<!-- /#wrapper -->


	<?php $this->load->view("admin/_partials/scrolltop.php") ?>
	<?php $this->load->view("admin/_partials/modal.php") ?>

	<?php $this->load->view("admin/_partials/js.php") ?>
    <script>
    function deleteConfirm(url){
        $('#btn-delete').attr('href', url);
        $('#deleteModal').modal();
    }
   	

   
$(document).ready(function(){
 
 $('.input-daterange').datepicker({
  todayBtn:'linked',
  format: "yyyy-mm-dd",
  autoclose: true
 });

 fetch_data('no');

 function fetch_data(is_date_search, start_date='', end_date='')
 {
  var dataTable = $('#order_data').DataTable({
   "processing" : true,
   "serverSide" : true,
   "order" : [],
   "ajax" : {
    url:"fetch.php",
    type:"POST",
    data:{
     is_date_search:is_date_search, start_date:start_date, end_date:end_date
    }
   }
  });
 }

 $('#search').click(function(){
  var start_date = $('#start_date').val();
  var end_date = $('#end_date').val();
  if(start_date != '' && end_date !='')
  {
   $('#order_data').DataTable().destroy();
   fetch_data('yes', start_date, end_date);
  }
  else
  {
   alert("Both Date is Required");
  }
 }); 
 
});

</script>
</body>


</html>