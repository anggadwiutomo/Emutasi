<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("superadmin/_partials/head.php") ?>

</head>

<body id="page-top">

<?php
        date_default_timezone_set('Asia/Jakarta');

        $tgl=strtotime(date('Y-m-d'));
        $clock=date('H:i');
        if (date('H')>=0 AND date('H')<8)
        {
            $tgl = date('Y-m-d',strtotime('-1day',$tgl));
        }
        else
        {
        	$tgl = date('Y-m-d',strtotime('today',$tgl));
        }

?>
	<?php $this->load->view("superadmin/_partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("superadmin/_partials/sidebar.php") ?>

		<div id="content-wrapper">

			<div class="container-fluid">

				<?php $this->load->view("superadmin/_partials/breadcrumb.php") ?>

				<?php if ($this->session->flashdata('success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo $this->session->flashdata('success'); ?>
				</div>
				<?php endif; ?>

				<div class="card mb-3">
					<div class="card-header">
						<a href="<?php echo site_url('superadmin/mutasi/') ?>"><i class="fas fa-arrow-left"></i> Back</a>
					</div>
					<div class="card-body">

						<form action="<?php base_url('superadmin/mutasi/add_piket') ?>" method="post" enctype="multipart/form-data" id="insert_form" >
							<div class="form-group">
								<label for="tanggal">Hari / Tanggal*</label>
								<input class="form-control <?php echo form_error('name') ? 'is-invalid':'' ?>"
								 type="text" name="tanggal" value="<?php echo $idunik ?>" />
								<div class="invalid-feedback">
									<?php echo form_error('tanggal') ?>
								</div>
							</div>

<!-- 							<div class="form-group">
								<label for="nama_petugas">Nama Petugas Piket*</label>
								<input class="form-control <?php echo form_error('price') ? 'is-invalid':'' ?>"
								 type="text" name="nama_petugas" id="nama_petugas" placeholder="Nama Petugas Piket" />
								<div class="invalid-feedback">
									<?php echo form_error('nama') ?>
								</div>
							</div>
 -->

 <div class="form-group">

	    <label for="name">Nama Petugas Piket*</label>
	    
	        <select required name="nama_petugas[]" id="nama_petugas" class="form-control" multiple="">
	        	<option value="" disabled diselected>-- Pilih Petugas --</option>
	        <?php                                
	        foreach ($opt_nama as $row) {  
			  echo "<option value='".$row->nrp."'>".$row->nrp." - ".$row->nama_personil."</option>";
			  }
			  echo"
			</select>"
			?>
		</div>
	    
<!-- 			    <div class="input_fields_wrap">
		    <button class="add_field_button">Add More Fields</button>
		    <div><input type="text" name="mytext[]"></div>
				</div> -->


							<input class="btn btn-success" type="submit" name="btn" value="Save" />
						</form>

					</div>

					<div class="card-footer small text-muted">
						* required fields
					</div>


				</div>
				<!-- /.container-fluid -->

				<!-- Sticky Footer -->
				<?php $this->load->view("superadmin/_partials/footer.php") ?>

			</div>
			<!-- /.content-wrapper -->

		</div>
		<!-- /#wrapper -->


		<?php $this->load->view("superadmin/_partials/scrolltop.php") ?>
				<?php $this->load->view("superadmin/_partials/modal.php") ?>

		<?php $this->load->view("superadmin/_partials/js.php") ?>

</body>
<script>
// $(document).ready(function() {
// 	var max_fields      = 10; //maximum input boxes allowed
// 	var wrapper   		= $(".input_fields_wrap"); //Fields wrapper
// 	var add_button      = $(".add_field_button"); //Add button ID
	
// 	var x = 1; //initlal text box count
// 	$(add_button).click(function(e){ //on add input button click
// 		e.preventDefault();
// 		if(x < max_fields){ //max input box allowed
// 			x++; //text box increment
// 			$(wrapper).append('<div><input type="text" name="mytext[]"/><a href="#" class="remove_field">Remove</a></div>'); //add input box
// 		}
// 	});
	
// 	$(wrapper).on("click",".remove_field", function(e){ //user click on remove text
// 		e.preventDefault(); $(this).parent('div').remove(); x--;
// 	})
// });

$(".js-example-tokenizer").select2({
    tags: true,
    tokenSeparators: [',', ' ']
})

$('select').select2({
  createTag: function (params) {
    var term = $.trim(params.term);

    if (term === '') {
      return null;
    }

    return {
      id: term,
      text: term,
      newTag: true // add additional parameters
    }
  }
});

$('select').select2({
  createTag: function (params) {
    // Don't offset to create a tag if there is no @ symbol
    if (params.term.indexOf('@') === -1) {
      // Return null to disable tag creation
      return null;
    }

    return {
      id: params.term,
      text: params.term
    }
  }
});
$('select').select2({
  insertTag: function (data, tag) {
    // Insert the tag at the end of the results
    data.push(tag);
  }
});


</script>
  </html>