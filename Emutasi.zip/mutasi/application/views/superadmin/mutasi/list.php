<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("superadmin/_partials/head.php") ?>
</head>

<body id="page-top">

	<?php $this->load->view("superadmin/_partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("superadmin/_partials/sidebar.php") ?>

		<div id="content-wrapper">

			<div class="container-fluid">

				<?php $this->load->view("superadmin/_partials/breadcrumb.php") ?>


						<!-- DataTables -->
							<div class="card mb-3">
								<div class="card-header">
									<h5>Buku Mutasi semua Departemen</h5>
									<!-- <a href="<?php echo site_url('superadmin/mutasi/add') ?>"><i class="fas fa-plus"></i> Add New</a> -->
								</div>
								<div class="card-body">

									<div class="table-responsive">
										<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
											<thead>
												<tr>
													<th width="10">No.</th>
													<th width="350">Hari / Tanggal</th>
													<th width="350">Departemen</th>	
													<th width="150">Mutasi</th>													
													<th width="400">Action</th>
													<th width="200">Status</th>
												</tr>
											</thead>
											<tbody>
												<?php $no = 1;?>
												<?php foreach ($mutasi as $mutasi): ?>
													<tr>
														<td>
															<?php echo $no ?>
														</td>
														<td>
															<?php echo tanggal_indo($mutasi->tgl) ?>
														</td>
														<td>
															<?php echo $mutasi->nama_dept ?>
														</td>
														<td>
															<a href="<?php echo site_url('superadmin/mutasi/get_mutasi_by_nama/'. $mutasi->id) ?>"
											 class="btn btn-small"><i class="fas fa-book"></i> Lihat Detail</a>
														</td>

														<td>
															<a target="BLANK" href="<?php echo site_url('superadmin/mutasi/print_temp/'.$mutasi->id) ?>"
																class="btn btn-small"><i class="fas fa-print"></i> Print</a>

																|
															<a target="BLANK" href="<?php echo site_url('superadmin/mutasi/cetak_temp/'.$mutasi->id) ?>"
																class="btn btn-small"><i class="fas fa-cloud-download-alt"></i> PDF</a>
														</td>
														<td>
																	<?php 
																	if($mutasi->status==0){
																		echo "<button type='button' class='btn btn-warning'>Belum dikonfirmasi</button>";

																	}else{
																		echo "<button type='button' class='btn btn-success'>Telah dikonfirmasi</button>";
																	
																	}
																	?>
																</td>
													</tr>
															<?php $no++;?>
														<?php endforeach; ?>
													</tbody>
												</table>
											</div>
										</div>
									</div>

								</div>
								<!-- /.container-fluid -->

								<!-- Sticky Footer -->
								<?php $this->load->view("superadmin/_partials/footer.php") ?>

							</div>
							<!-- /.content-wrapper -->

						</div>
						<!-- /#wrapper -->


						<?php $this->load->view("superadmin/_partials/scrolltop.php") ?>
						<?php $this->load->view("superadmin/_partials/modal.php") ?>

						<?php $this->load->view("superadmin/_partials/js.php") ?>
						<script>
							function deleteConfirm(url){
								$('#btn-delete').attr('href', url);
								$('#deleteModal').modal();
							}

						</script>
					</body>


					</html>