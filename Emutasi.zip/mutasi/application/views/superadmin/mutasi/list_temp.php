<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("superadmin/_partials/head.php") ?>
</head>

<body id="page-top">

	<?php $this->load->view("superadmin/_partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("superadmin/_partials/sidebar.php") ?>

		<div id="content-wrapper">

			<div class="container-fluid">

				
				<div class="card mb-3">
					<div class="card-header">
							<div style="padding-left: 10px" class="accordion float-right" id="accordionExample">
								<?php foreach ($nama_penjaga as $m):
									$tgl= $m->tgl ;										
								endforeach;
								echo tanggal_indo($tgl);
								?>
							</div>
<h5>Petugas Piket</h5>
						</div>
						<div class="card-body">

							<div class="table-responsive">
								<table class="table table-bordered" width="100%" cellspacing="0">
									<thead>
										<tr>
											<th width="50">No.</th>
											<th width="400">NRP</th>
											<th width="600">Nama Petugas</th>
										</tr>
									</thead>
									<tbody>
										<?php $no = 1; ?>
										<?php 
										foreach ($nama_penjaga as $m):
											$var= $m->nrp_personil ;										
											
										endforeach;

										// $pieces = explode(",", $var);
										// foreach($pieces as $element):	
										?>
										<?php
	        						// $this->db->from('personil');
									// $query = $this->db->get();
	           						// $isDefined = isset($var);
										if(isset($var)){
											$sql ="SELECT * FROM personil where nrp in ($var) UNION SELECT * FROM user where nrp in ($var)";
											$query = $this->db->query($sql);
											if ($query->num_rows() > 0) {
												foreach ($query->result() as $row) {
													?>
													<tr>
														<td><?php echo $no;?></td>
														<td><?php echo $row->nrp; ?></td>
														<td><?php echo $row->nama; ?></td>

														</tr>
														<?php $no++;?>
													<?php }}} ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>

							<!-- DataTables -->


							<div class="card mb-3">
								<div class="card-header">
										<div style="padding-left: 10px" class="accordion float-right" id="accordionExample">
								<?php 
						
								echo tanggal_indo($tgl);
								?>
							</div>
<h5>Mutasi</h5>
								</div>
								<div class="card-body">

									<div class="table-responsive">
										<table class="table table-bordered" width="100%" cellspacing="0">
											<thead>
												<tr>
													<th width="10">No.</th>
													<th width="100">Jam</th>
													<th width="200">Departemen</th>
													<th width="800">Mutasi</th>
												</tr>
											</thead>
											<tbody>
												<?php $no = 1;?>
												<?php foreach ($mutasi as $personil): ?>
													<tr>
														<td>
															<?php echo $no ?>
														</td>
														<td>
															<?php echo $personil->jam ?>
														</td>
														<td>
															<?php echo $personil->nama_dept ?>
														</td>
														<td>
															<?php echo $personil->mutasi ?>
														</td>
<!-- 										<td class="small">
											<?php echo $personil->departemen ?>
										</td>
										<td width="250">
											<a href="<?php echo site_url('superadmin/personil/edit/'.$personil->nrp) ?>"
											 class="btn btn-small"><i class="fas fa-edit"></i> Edit</a>
											<a onclick="deleteConfirm('<?php echo site_url('superadmin/personil/delete/'.$personil->nrp) ?>')"
											 href="#!" class="btn btn-small text-danger"><i class="fas fa-trash"></i> Hapus</a>
										</td>
									-->									</tr>
									<?php $no++;?>
								<?php endforeach; ?>

							</tbody>
						</table>
					</div>
				</div>
			</div>

		</div>
		<!-- /.container-fluid -->	
		
		<!-- /.container-fluid -->
		
		<!-- Sticky Footer -->
		<?php $this->load->view("superadmin/_partials/footer.php") ?>

	</div>
	<!-- /.content-wrapper -->

</div>
<!-- /#wrapper -->


<?php $this->load->view("superadmin/_partials/scrolltop.php") ?>
<?php $this->load->view("superadmin/_partials/modal.php") ?>

<?php $this->load->view("superadmin/_partials/js.php") ?>
<script>
	function deleteConfirm(url){
		$('#btn-delete').attr('href', url);
		$('#deleteModal').modal();
	}
</script>
</body>


</html>