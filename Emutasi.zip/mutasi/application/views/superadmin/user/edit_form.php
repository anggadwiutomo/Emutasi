<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("superadmin/_partials/head.php") ?>
</head>

<body id="page-top">

	<?php $this->load->view("superadmin/_partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("superadmin/_partials/sidebar.php") ?>

		<div id="content-wrapper">

			<div class="container-fluid">

				<?php $this->load->view("superadmin/_partials/breadcrumb.php") ?>

				<?php if ($this->session->flashdata('success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo $this->session->flashdata('success'); ?>
				</div>
				<?php endif; ?>

				<!-- Card  -->
				<div class="card mb-3">
					<div class="card-header">

						<a href="<?php echo site_url('superadmin/users/') ?>"><i class="fas fa-arrow-left"></i>
							Back</a>
					</div>
					<div class="card-body">

						<form action="<?php base_url('superadmin/user/edit') ?>" method="post" enctype="multipart/form-data">

							<input type="hidden" name="id" value="<?php echo $user->nrp?>" />

							<div class="form-group">
								<label for="nrp">NRP*</label>
								<input class="form-control <?php echo form_error('nrp') ? 'is-invalid':'' ?>"
								 type="text" name="nrp"  readonly="readonly" value="<?php echo $user->nrp ?>" />
								<div class="invalid-feedback">
									<?php echo form_error('nrp') ?>
								</div>
							</div>

							<div class="form-group">
								<label for="nama">Nama Lengkap*</label>
								<input class="form-control <?php echo form_error('nama') ? 'is-invalid':'' ?>"
								 type="text" name="nama" placeholder="Nama" value="<?php echo $user->nama ?>" />
								<div class="invalid-feedback">
									<?php echo form_error('nama') ?>
								</div>
							</div>
							<div class="form-group">
								<label for="pangkat">Pangkat</label>

								<select required name="pangkat" class="form-control">
									<option value="" disabled diselected>-- Pilih Pangkat --</option>
									<?php
									foreach ($opt_pangkat as $row) {  
										if($row->pangkat_id==$user->pangkat){
											echo "<option value='".$row->pangkat_id."' selected>".$row->pangkat."</option>";
										}
										else{
											echo "<option value='".$row->pangkat_id."'>".$row->pangkat."</option>";
										}

									}
									echo"
									</select>"
									?>
								</div>			

							<div class="form-group">
								<label for="departemen">Departemen</label>

								<select required name="departemen" class="form-control">
									<option value="" disabled diselected>-- Pilih Pangkat --</option>
									<?php
									foreach ($opt_dept as $row) {  
										if($row->dept_id==$user->departemen){
											echo "<option value='".$row->dept_id."' selected>".$row->nama_dept."</option>";
										}
										else{
											echo "<option value='".$row->dept_id."'>".$row->nama_dept."</option>";
										}

									}
									echo"
									</select>"
									?>
								</div>			
							<div class="form-group">
										<label for="password">Password*</label>
										<input class="form-control <?php echo form_error('pass') ? 'is-invalid':'' ?>"
										type="password" name="password" placeholder="Password" />
										<div class="invalid-feedback">
											<?php echo form_error('pass') ?>
										</div>
									</div>
									<div class="form-group">
										<label for="password_validation">Ulangi Password*</label>
										<input class="form-control <?php echo form_error('password_validation') ? 'is-invalid':'' ?>"
										type="password" name="password_validation" placeholder="Password" />
										<div class="invalid-feedback">
											<?php echo form_error('password_validation') ?>
										</div>
									</div>
									<?php 
								if($user->level==1){
									?>
									<div class="form-group">
										<label for="level">Level*</label>
										<select required name="level" class="form-control">
											<option value="" disabled diselected>-- Pilih Level  --</option>
											<option value="1" selected>1 - Superadmin</option>
											<option value="2">2 - Admin</option>
										</select>

									</div>
								<?php } else{?>
																		<div class="form-group">
										<label for="level">Level*</label>
										<select required name="level" class="form-control">
											<option value="" disabled diselected>-- Pilih Level  --</option>
											<option value="1">1 - Superadmin</option>
											<option value="2" selected>2 - Admin</option>
										</select>

									</div>
								<?php }?>
							<input class="btn btn-success" type="submit" name="btn" value="Save" />
						</form>

					</div>

					<div class="card-footer small text-muted">
						* required fields
					</div>


				</div>
				<!-- /.container-fluid -->

				<!-- Sticky Footer -->
				<?php $this->load->view("superadmin/_partials/footer.php") ?>

			</div>
			<!-- /.content-wrapper -->

		</div>
		<!-- /#wrapper -->

		<?php $this->load->view("superadmin/_partials/scrolltop.php") ?>
			<?php $this->load->view("superadmin/_partials/modal.php") ?>

		<?php $this->load->view("superadmin/_partials/js.php") ?>

</body>

</html>