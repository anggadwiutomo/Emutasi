<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("superadmin/_partials/head.php") ?>
</head>

<body id="page-top">
	<?php $this->load->view("superadmin/_partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("superadmin/_partials/sidebar.php") ?>

		<div id="content-wrapper">

			<div class="container-fluid">

				<?php $this->load->view("superadmin/_partials/breadcrumb.php") ?>

				<?php if ($this->session->flashdata('success')): ?>
					<div class="alert alert-success" role="alert">
						<?php echo $this->session->flashdata('success'); ?>
					</div>
				<?php endif; ?>

				<div class="card mb-3">
					<div class="card-header">
						<a href="<?php echo site_url('superadmin/user/') ?>"><i class="fas fa-arrow-left"></i> Back</a>
					</div>
					<div class="card-body">

						<form action="<?php base_url('superadmin/user/add') ?>" method="post" enctype="multipart/form-data" >
							<div class="form-group">
								<label for="nrp">NRP*</label>
								<input class="form-control <?php echo form_error('nrp') ? 'is-invalid':'' ?>"
								type="text" name="nrp" placeholder="NRP" />
								<div class="invalid-feedback">
									<?php echo form_error('nrp') ?>
								</div>
							</div>

							<div class="form-group">
								<label for="nama">Nama Lengkap*</label>
								<input class="form-control <?php echo form_error('nama') ? 'is-invalid':'' ?>"
								type="text" name="nama" min="0" placeholder="Nama Lengkap" />
								<div class="invalid-feedback">
									<?php echo form_error('nama') ?>
								</div>
							</div>
							<div class="form-group">
									<label for="name">Pangkat</label>

									<select required name="pangkat" class="form-control">
										<option value="" disabled diselected>-- Pilih Pangkat --</option>
										<?php                                
										foreach ($opt_pangkat as $row) {  
											echo "<option value='".$row->pangkat_id."'>".$row->pangkat."</option>";
										}
										echo"
										</select>"
										?>
									</div>		
							<div class="form-group">
								<label for="name">Departemen</label>

								<select required name="departemen" class="form-control">
									<option value="" disabled diselected>-- Pilih Departemen --</option>
									<?php                                
									foreach ($opt_dept as $row) {  
										echo "<option value='".$row->dept_id."'>".$row->dept_id." - ".$row->nama_dept."</option>";
									}
									echo"
									</select>"
									?>
								</div>			
												
									<div class="form-group">
										<label for="password">Password*</label>
										<input class="form-control <?php echo form_error('pass') ? 'is-invalid':'' ?>"
										type="password" name="password" placeholder="Password" />
										<div class="invalid-feedback">
											<?php echo form_error('pass') ?>
										</div>
									</div>
									<div class="form-group">
										<label for="password_validation">Ulangi Password*</label>
										<input class="form-control <?php echo form_error('password_validation') ? 'is-invalid':'' ?>"
										type="password" name="password_validation" placeholder="Password" />
										<div class="invalid-feedback">
											<?php echo form_error('password_validation') ?>
										</div>
									</div>
									<div class="form-group">
										<label for="level">Level*</label>
										<select required name="level" class="form-control">
											<option value="" disabled diselected>-- Pilih Level --</option>
											<option value="1">1 - Superadmin</option>
											<option value="2">2 - Admin</option>
										</select>

									</div>

									<input class="btn btn-success" type="submit" name="btn" value="Save" />
								</form>

							</div>

							<div class="card-footer small text-muted">
								* required fields
							</div>


						</div>
						<!-- /.container-fluid -->

						<!-- Sticky Footer -->
						<?php $this->load->view("superadmin/_partials/footer.php") ?>

					</div>
					<!-- /.content-wrapper -->

				</div>
				<!-- /#wrapper -->


				<?php $this->load->view("superadmin/_partials/scrolltop.php") ?>
				<?php $this->load->view("superadmin/_partials/modal.php") ?>
				<?php $this->load->view("superadmin/_partials/js.php") ?>

			</body>

			</html>