
<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view("superadmin/_partials/head.php") ?>

	<!-- Filter -->
	 <link rel="stylesheet" href="<?php echo base_url('assets/jquery-ui/jquery-ui.min.css'); ?>" /> <!-- Load file css jquery-ui -->
    <script src="<?php echo base_url('assets/jquery.min.js'); ?>"></script> <!-- Load file jquery -->
</head>
<body id="page-top">
	

<?php $this->load->view("superadmin/_partials/navbar.php") ?>

<div id="wrapper">

	<?php $this->load->view("superadmin/_partials/sidebar.php") ?>

	<div id="content-wrapper">

		<div class="container-fluid">

        <!-- 
        karena ini halaman overview (home), kita matikan partial breadcrumb.
        Jika anda ingin mengampilkan breadcrumb di halaman overview,
        silahkan hilangkan komentar (//) di tag PHP di bawah.
        -->
		<?php //$this->load->view("superadmin/_partials/breadcrumb.php") ?>

		<!-- Icon Cards-->
		     
		<div class="row">
			<div class="col-xl-3 col-sm-6 mb-3">
			<div class="card text-white bg-primary o-hidden h-80">
				<div class="card-body">
					<div class="card-body-icon">
						<i class="fas fa-user-secret"></i>
					</div>
					<div class="mr-5">
						<h3><?php echo $admin?></h3>
							Admin
					</div>
				</div>
				<!-- <a class="card-footer text-white clearfix small z-1" href="<?php echo site_url('superadmin/users') ?>">
				<span class="float-left">View Details</span>
				<span class="float-right">
					<i class="fas fa-angle-right"></i>
				</span>
				</a>
 -->			</div>
			</div>
			<div class="col-xl-3 col-sm-6 mb-3">
			<div class="card text-white bg-warning o-hidden h-80">
				<div class="card-body">
				<div class="card-body-icon">
					<i class="fas fa-users"></i>
				</div>
				<div class="mr-5">
					<h3><?php echo $client ?></h3>
					Personil
				</div>
				</div>
<!-- 				<a class="card-footer text-white clearfix small z-1" href="<?php echo site_url('superadmin/personil') ?>">
				<span class="float-left">View Details</span>
				<span class="float-right">
					<i class="fas fa-angle-right"></i>
				</span>
				</a> -->
			</div>
			</div>
			<div class="col-xl-3 col-sm-6 mb-3">
			<div class="card text-white bg-success o-hidden h-80">
				<div class="card-body">
				<div class="card-body-icon">
					<i class="fas fa-building"></i>
				</div>
				<div class="mr-5">
					<h3><?php echo $departemen ?></h3>
					Departemen
				</div>
				</div>
				<!-- <a class="card-footer text-white clearfix small z-1" href="<?php echo site_url('superadmin/departemen') ?>">
				<span class="float-left">View Details</span>
				<span class="float-right">
					<i class="fas fa-angle-right"></i>
				</span>
				</a> -->
			</div>
			</div>
			<div class="col-xl-3 col-sm-6 mb-3">
			<div class="card text-white bg-danger o-hidden h-80">
				<div class="card-body">
				<div class="card-body-icon">
					<i class="fas fa-book"></i>
				</div>
					<div class="mr-5">
						<h3><?php echo $mutasi_total ?></h3>
						Mutasi
					</div>
				</div>
<!-- 				<a class="card-footer text-white clearfix small z-1" href="<?php echo site_url('superadmin/mutasi') ?>">
				<span class="float-left">View Details</span>
				<span class="float-right">
					<i class="fas fa-angle-right"></i>
				</span>
				</a> -->
			</div>
			</div>
		</div>


		<!-- Filter -->
		<form method="get" action="" class="float-left">
        <h5><label>Filter Berdasarkan :</label><br></h5>
        <select name="filter" id="filter" class="btn btn-secondary dropdown-toggle">
            <option value="">Pilih</option>
            <option value="1">Tanggal</option>
            <option value="2">Departemen</option>
            <option value="3">Tanggal & Departemen</option>
        </select>
        <br /><br />

        <div id="form-tanggal">
            <label>Tanggal</label><br>
            <input type="text" name="tanggal" class="input-tanggal" />
            <br /><br />
        </div>

        <div id="form-dept">
            <label>Departemen</label><br>

            <select name="dept" class="btn btn-secondary dropdown-toggle">
                <option value="">-Pilih Departemen-</option>
                <?php
                foreach ($opt_dept as $row) {  
										echo "<option value='".$row->dept_id."'>".$row->dept_id." - ".$row->nama_dept."</option>";
                }
                ?>
            </select>
            <br /><br />
        </div>

         <a href="<?php echo site_url('superadmin/overview') ?>" class="btn btn-danger" >Reset Filter</a>
        <button type="submit" class="btn btn-success">Tampilkan</button>
       
    </form>



		<!-- Area Chart Example-->
									<!-- DataTables -->
							<div class="card mb-3">
								<!-- <div class="card-header">
									 <a href="<?php echo site_url('superadmin/mutasi/add') ?>"><i class="fas fa-plus"></i> Add New</a> 
								</div> -->
								<div class="card-body">

									<div class="table-responsive">
										<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
											<thead>
												<tr>
													<th>No.</th>
													<th>Tanggal</th>
													<th>Jam</th>
													<th>Departemen</th>
													<th>Piket</th>													
													<th>Mutasi</th>
													
												</tr>
											</thead>
											<tbody>
												<?php $no = 1;?>
												<?php foreach ($mutasix as $mutasi): ?>
													<tr>
														<td >
															<?php echo $no ?>
														</td> 
														<td width="150">
															<?php echo tanggal_indo($mutasi->tanggal) ?>
														</td>
														<td>
															<?php echo $mutasi->jam ?>
														</td>
														<td>
															<?php echo $mutasi->nama_dept ?>
														</td>
														<td>
															<a href="<?php echo site_url('superadmin/mutasi/get_nama_by_mutasi/'. $mutasi->nama_petugas) ?>"
											 class="btn btn-small"><i class="fas fa-list"></i> Detail</a>
														</td>

														<td width="250">
															<?php echo $mutasi->mutasi ?>
														</td>
														
															</tr>
															<?php $no++;?>
														<?php endforeach; ?>
													</tbody>
												</table>
											</div>
										</div>
									</div>

								</div>
			

								<!-- Sticky Footer -->
								<?php $this->load->view("superadmin/_partials/footer.php") ?>

							</div>
							<!-- /.content-wrapper -->

						</div>
						<!-- /#wrapper -->


		<!-- /.container-fluid -->

		<!-- Sticky Footer -->
		<?php $this->load->view("superadmin/_partials/footer.php") ?>

	</div>
	<!-- /.content-wrapper -->

</div>
<!-- /#wrapper -->


<?php $this->load->view("superadmin/_partials/scrolltop.php") ?>
<?php $this->load->view("superadmin/_partials/modal.php") ?>
<?php $this->load->view("superadmin/_partials/js.php") ?>


<!-- Filter -->
						<script src="<?php echo base_url('assets/jquery-ui/jquery-ui.min.js'); ?>"></script> <!-- Load file plugin js jquery-ui -->
    <script>
    $(document).ready(function(){ // Ketika halaman selesai di load
        $('.input-tanggal').datepicker({
            dateFormat: 'yy-mm-dd' // Set format tanggalnya jadi yyyy-mm-dd
        });

        $('#form-tanggal, #form-dept').hide(); // Sebagai default kita sembunyikan form filter tanggal, bulan

        $('#filter').change(function(){ // Ketika user memilih filter
            if($(this).val() == '1'){ // Jika filter nya 1 (per tanggal)
                $('#form-dept').hide(); // Sembunyikan form bulan dan tahun
                $('#form-tanggal').show(); // Tampilkan form tanggal
            }else if ($(this).val() == '2') {
            	$('#form-tanggal').hide(); // Tampilkan form tanggal
            	$('#form-dept').show(); // Sembunyikan form bulan dan tahun
            }else { // Jika filter nya 2 (per bulan)
                $('#form-tanggal, #form-dept').show(); // Tampilkan form bulan dan tahun
            }

            $('#form-tanggal input, #form-dept select').val(''); // Clear data pada textbox tanggal, combobox bulan & tahun
        })
    })
    </script>
    
</body>
</html>
	