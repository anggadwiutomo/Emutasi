<!-- Sidebar -->
<?php  if($this->session->userdata('masuk') != TRUE){
    $url=base_url();
    redirect($url);
}
?>

    <ul class="sidebar navbar-nav">
    <li class="nav-item <?php echo $this->uri->segment(2) == '' ? 'active': '' ?>">
        <a class="nav-link" href="<?php echo site_url('superadmin') ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>

       <li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'mutasi' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
        aria-expanded="false">
        <i class="fas fa-fw fa-book"></i>
        <span>Buku Mutasi</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <a class="dropdown-item" href="<?php echo site_url('superadmin/mutasi') ?>">Daftar Buku Mutasi</a>
    </div>
</li>
<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'users' ? 'active' : '' ?>">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-hashpopup="true" aria-expanded="false">
        <i class="fas fa-fw fa-user-secret"></i>
        <span>Admin</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <a class="dropdown-item" href="<?php echo site_url('superadmin/users/add') ?>">Tambah Admin</a>
        <a class="dropdown-item" href="<?php echo site_url('superadmin/users') ?>">Daftar Admin</a>
    </div>
</li>

<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'departemen' ? 'active' : '' ?>">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-hashpopup="true" aria-expanded="false">
        <i class="fas fa-fw fa-building"></i>
        <span>Departemen</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <a class="dropdown-item" href="<?php echo site_url('superadmin/departemen/add') ?>">Tambah Departemen</a>
        <a class="dropdown-item" href="<?php echo site_url('superadmin/departemen') ?>">Daftar Departemen</a>
    </div>
</li>



<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'pangkat' ? 'active' : '' ?>">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-hashpopup="true" aria-expanded="false">
        <i class="fas fa-fw fa fa-angle-double-down"></i>
        <span>Pangkat</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <a class="dropdown-item" href="<?php echo site_url('superadmin/pangkat/add') ?>">Tambah Pangkat</a>
        <a class="dropdown-item" href="<?php echo site_url('superadmin/pangkat') ?>">Daftar Pangkat</a>
    </div>
</li>



<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'settings' ? 'active' : '' ?>">
    <a class="nav-link" href="<?php echo site_url('superadmin/settings') ?>">
    <i class="fas fa-fw fa-cog"></i>
    <span>Settings</span>
</a>
<!-- <div class="dropdown-menu" aria-labelledby="pagesDropdown">
    <h6 class="dropdown-header">Login Screens:</h6>

    <a class="dropdown-item" href="<?php echo site_url('admin/personil/edit/') ?>">Login</a>
    <a class="dropdown-item" href="register.html">Register</a>
    <a class="dropdown-item" href="forgot-password.html">Forgot Password</a>
    <div class="dropdown-divider"></div>
    <h6 class="dropdown-header">Other Pages:</h6>
    <a class="dropdown-item" href="404.html">404 Page</a>
    <a class="dropdown-item" href="blank.html">Blank Page</a>
</div> -->
</li>
</ul>
