
<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>
<body id="page-top">
	

<?php $this->load->view("admin/_partials/navbar.php") ?>

<div id="wrapper">

	<?php $this->load->view("admin/_partials/sidebar.php") ?>
											<?php 
											foreach ($penjaga as $m):
												$var= $m->nrp_personil ;										
											endforeach;
											if(isset($var)){
											$piket=0;
										$pieces = explode(",", $var);
										foreach($pieces as $element):
											$piket++;
										endforeach;	
									}
											?>

	<div id="content-wrapper">

		<div class="container-fluid">

        <!-- 
        karena ini halaman overview (home), kita matikan partial breadcrumb.
        Jika anda ingin mengampilkan breadcrumb di halaman overview,
        silahkan hilangkan komentar (//) di tag PHP di bawah.
        -->
		<?php //$this->load->view("admin/_partials/breadcrumb.php") ?>

		<!-- Icon Cards-->
		<!-- Icon Cards-->
		     
		<div class="row">
			<div class="col-xl-3 col-sm-6 mb-3">
			<div class="card text-white bg-primary o-hidden h-80">
				<div class="card-body">
					<div class="card-body-icon">
						<i class="fas fa-user-secret"></i>
					</div>
					<div class="mr-5">
						<h3><?php echo $admin?></h3>
							Admin
					</div>
				</div>
				<!-- <a class="card-footer text-white clearfix small z-1" href="<?php echo site_url('admin/users') ?>">
				<span class="float-left">View Details</span>
				<span class="float-right">
					<i class="fas fa-angle-right"></i>
				</span>
				</a>
 -->			</div>
			</div>
			<div class="col-xl-3 col-sm-6 mb-3">
			<div class="card text-white bg-warning o-hidden h-80">
				<div class="card-body">
				<div class="card-body-icon">
					<i class="fas fa-users"></i>
				</div>
				<div class="mr-5">
					<h3><?php echo $personil ?></h3>
					Personil
				</div>
				</div>
<!-- 				<a class="card-footer text-white clearfix small z-1" href="<?php echo site_url('admin/personil') ?>">
				<span class="float-left">View Details</span>
				<span class="float-right">
					<i class="fas fa-angle-right"></i>
				</span>
				</a> -->
			</div>
			</div>
			<div class="col-xl-3 col-sm-6 mb-3">
			<div class="card text-white bg-success o-hidden h-80">
				<div class="card-body">
				<div class="card-body-icon">
					<i class="fas fa-user-tie"></i>
				</div>
				<div class="mr-5">
						<?php 
						if(isset($piket)){
						echo  "<h3>".$piket."</h3>";
											echo "Petugas Piket";
										}
											else{
												echo "<h3>0	</h3> Petugas Piket";
											}
						 ?>

				</div>
				</div>
				<!-- <a class="card-footer text-white clearfix small z-1" href="<?php echo site_url('admin/departemen') ?>">
				<span class="float-left">View Details</span>
				<span class="float-right">
					<i class="fas fa-angle-right"></i>
				</span>
				</a> -->
			</div>
			</div>
			<div class="col-xl-3 col-sm-6 mb-3">
			<div class="card text-white bg-danger o-hidden h-80">
				<div class="card-body">
				<div class="card-body-icon">
					<i class="fas fa-book"></i>
				</div>
					<div class="mr-5">
						<h3><?php echo $mutasi_total ?></h3>
						Mutasi
					</div>
				</div>
<!-- 				<a class="card-footer text-white clearfix small z-1" href="<?php echo site_url('admin/mutasi') ?>">
				<span class="float-left">View Details</span>
				<span class="float-right">
					<i class="fas fa-angle-right"></i>
				</span>
				</a> -->
			</div>
			</div>
		</div>







	<!-- DataTables -->
							<div class="card mb-3">
								<div class="card-header">
									<!-- <a href="<?php echo site_url('admin/mutasi/add') ?>"><i class="fas fa-plus"></i> Add New</a> -->
									<h5>Riwayat Buku Mutasi </h5>
								</div>
								<div class="card-body">

									<div class="table-responsive">
										<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
											<thead>
												<tr>
												<th width="10">No.</th>
													<th width="400">Hari / Tanggal</th>
													<th width="200">Mutasi</th>													
													<th width="200">Print</th>
													<th width="200">Status</th>

												</tr>
											</thead>
											<tbody>
												<?php $no = 1;?>
												<?php foreach ($mutasi as $mutasi): ?>
													<tr>
														<td>
															<?php echo $no ?>
														</td>
														<td width="150">
															<?php echo tanggal_indo($mutasi->tgl) ?>
														</td>
														<td>
															<a href="<?php echo site_url('admin/mutasi/get_mutasi_by_nama/'. $mutasi->id) ?>"
											 class="btn btn-small"><i class="fas fa-book"></i> Lihat Detail</a>
														</td>

														<td width="250">
															<a target="BLANK" href="<?php echo site_url('admin/mutasi/print_temp/'.$mutasi->id) ?>"
																class="btn btn-small"><i class="fas fa-print"></i> Print</a>
																|
 															<a target="BLANK" href="<?php echo site_url('admin/mutasi/cetak_temp/'.$mutasi->id) ?>"
																class="btn btn-small"><i class="fas fa-cloud-download-alt"></i> PDF</a>

																</td>
														<td>
															<?php 
															 $nrp_pelaksana = $this->session->userdata['ses_nrp'];
															if($mutasi->nrp_pelaksana==$nrp_pelaksana AND $mutasi->status==0){

																// echo "Terima"; 
																?>
																<a href="<?php echo site_url('admin/mutasi/editStatus/'.$mutasi->id) ?>"><button type="button" class="btn btn-primary">Konfirmasi</button></a>
																	<?php 
															}elseif($mutasi->status==1){
																echo "<button type='button' class='btn btn-success'>Telah dikonfirmasi</button>";																
															}
															else
															{

																echo "<button type='button' class='btn btn-warning'>Anda bukan pelaksana</button>";
																 

															}?>
															
														</td>

															</tr>
															<?php $no++;?>
														<?php endforeach; ?>
													</tbody>
												</table>
											</div>
										</div>
									</div>

								</div>
								<!-- /.container-fluid -->


								</div>
								<!-- /.container-fluid -->

		<!-- Area Chart Example-->
			

								<!-- Sticky Footer -->
								<?php $this->load->view("admin/_partials/footer.php") ?>

							</div>
							<!-- /.content-wrapper -->

						</div>
						<!-- /#wrapper -->


		<!-- /.container-fluid -->

		<!-- Sticky Footer -->
		<?php $this->load->view("admin/_partials/footer.php") ?>

	</div>
	<!-- /.content-wrapper -->

</div>
<!-- /#wrapper -->


<?php $this->load->view("admin/_partials/scrolltop.php") ?>
<?php $this->load->view("admin/_partials/modal.php") ?>
<?php $this->load->view("admin/_partials/js.php") ?>
    
</body>
</html>
	