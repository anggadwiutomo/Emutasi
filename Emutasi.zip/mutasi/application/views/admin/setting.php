

<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view("admin/_partials/head.php") ?>
</head>

<body id="page-top">
    <?php
    $dept = $this->session->userdata['ses_dept']; 
    $nama = $this->session->userdata['ses_nama']; 

    $nrp = $this->session->userdata['ses_nrp'];
    $pangkat = $this->session->userdata['ses_pangkat'];   
    ?>

    <?php $this->load->view("admin/_partials/navbar.php") ?>
    <div id="wrapper">

        <?php $this->load->view("admin/_partials/sidebar.php") ?>

        <div id="content-wrapper">

            <div class="container-fluid">

                <?php $this->load->view("admin/_partials/breadcrumb.php") ?>

                <?php if ($this->session->flashdata('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                <?php endif; ?>

                <!-- Card  -->
                <div class="card mb-3">
                    <div class="card-header">

                        <a href="<?php echo site_url('admin/overview') ?>"><i class="fas fa-arrow-left"></i>
                        Back</a>
                    </div>
                    <div class="card-body">

                            <div class="form-group">
                                <label for="nrp">NRP*</label>
                                <input class="form-control <?php echo form_error('nrp') ? 'is-invalid':'' ?>"
                                type="text" readonly="readonly" name="nrp" value="<?php echo $nrp ?>" />
                                
                            </div>

                            <div class="form-group">
                                <label for="nama_personil">Nama Personil*</label>
                                <input class="form-control <?php echo form_error('price') ? 'is-invalid':'' ?>"
                                type="text" readonly="readonly" name="nama_personil" placeholder="Nama Personil" value="<?php echo $nama?>" />
                            </div>


                                        <?php echo form_open('admin/settings', array('id' => 'passwordForm'))?>
                                        <div class="form-group">
                                             <label for="nama_personil">Password Lama</label>
                                            <input type="password" name="oldpass" id="oldpass" class="form-control" placeholder="Old Password" />
                                            <?php echo form_error('oldpass', '<div class="error">', '</div>')?>
                                        </div>
                                        <div class="form-group">
                                             <label for="nama_personil">Password Baru</label>
                                            <input type="password" name="newpass" id="newpass" class="form-control" placeholder="New Password" />
                                            <?php echo form_error('newpass', '<div class="error">', '</div>')?>
                                        </div>
                                        <div class="form-group">
                                             <label for="nama_personil">Konfirmasi Password Baru</label>
                                            <input type="password" name="passconf" id="passconf" class="form-control" placeholder="Confirm New Password" />
                                            <?php echo form_error('passconf', '<div class="error">', '</div>')?>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                        </div>
                                        <?php echo form_close(); ?>
                                    
                               
                               

                        </div>

                        <div class="card-footer small text-muted">
                            * required fields
                        </div>


                    </div>
                    <!-- /.container-fluid -->

                    <!-- Sticky Footer -->
                    <?php $this->load->view("admin/_partials/footer.php") ?>

                </div>
                <!-- /.content-wrapper -->

            </div>
            <!-- /#wrapper -->

            <?php $this->load->view("admin/_partials/scrolltop.php") ?>
        <?php $this->load->view("admin/_partials/modal.php") ?>
            <?php $this->load->view("admin/_partials/js.php") ?>

        </body>

        </html>