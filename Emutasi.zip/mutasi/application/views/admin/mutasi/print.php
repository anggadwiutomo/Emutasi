<!DOCTYPE html>
<html lang="en">

<head>
</head>

<body>

	<img src="<?php echo base_url()?>assets/image/Header.png">

	<?php
		error_reporting(E_ALL ^ E_NOTICE);
		foreach ($mutasi as $m):
		$var= $m->tanggal;


		endforeach;

		foreach ($nama_penjaga as $st):
		$status= $st->status;
		$date=$st->tgl;
		$nrp_pelaksana= $st->nrp_pelaksana;
		$nrp_penerima= $st->nrp_penerima;
		$nrp_personil= $st->nrp_personil;
		endforeach;
		
		$pieces = explode(",", $nrp_personil);
		foreach($pieces as $element):
			$nrp_piket = $element;
		endforeach;

		$sql ="SELECT * FROM personil where nrp='$nrp_piket'";
			$query = $this->db->query($sql);
			if ($query->num_rows() > 0) {
			foreach ($query->result() as $row) {
				$nrp_piket = $row->nrp;
				$nama_piket = $row->nama;
			}
		}

		$sql ="SELECT * FROM mutasi_personil INNER JOIN personil ON mutasi_personil.nrp_penerima=personil.nrp WHERE mutasi_personil.tgl='$date'";
			$query = $this->db->query($sql);
			if ($query->num_rows() > 0) {
			foreach ($query->result() as $row) {
				$nama_penerima = $row->nama;
			}
		}
		$sql ="SELECT * FROM mutasi_personil INNER JOIN user ON mutasi_personil.nrp_pelaksana=user.nrp WHERE mutasi_personil.tgl='$date'";
			$query = $this->db->query($sql);
			if ($query->num_rows() > 0) {
			foreach ($query->result() as $row) {
				$nama_pelaksana = $row->nama;
			}
		}

		
	?>

	<?php
        date_default_timezone_set('Asia/Jakarta');

        $tgl=strtotime(date($date));
        $tgl = date('Y-m-d',strtotime('+1day',$tgl));
        

	?>

	<p style="text-align: right;">Hari, Tanggal : <?php if(isset($date)) echo tanggal_indo($date);?></p><br>
    <p>Anggota Piket :</p>

    <style>
		table {
			border-collapse:collapse;
			table-layout:fixed;
			cellpadding:10;
		}
		table td {
			word-wrap:break-word;
			text-align: center;
			padding: 5px;
		}
		table th{
			word-wrap:break-word;
			text-align: center;
			padding: 5px;
		}
		p{
			margin: 0;
			padding: 0;
			border: 0;
			font-size: 100%;
			font: inherit;
			vertical-align: baseline;
		}
	</style>

	<table border="1" width="100%">
	<tr>
		<th width="6%">No</th>
        <th width="47%">NRP</th>
        <!-- <th width="47%">Pangkat</th> -->
        <th width="47%">Nama</th>
	</tr>

	<!-- Tabel Untuk Nama Petugas Piket -->
    	<?php $no = 1; ?>
		<?php 
		foreach ($nama_penjaga as $m):
		$var= $m->nrp_personil;					

		endforeach;	
		?>
		    <?php
			if(isset($var)){
		    $sql ="SELECT * FROM personil where nrp in ($var)";
			$query = $this->db->query($sql);
			if ($query->num_rows() > 0) {
			foreach ($query->result() as $row) {
	    ?>
		<tr>
		<td ><?php echo $no;?></td>
		<td ><?php echo $row->nrp; ?></td>
		<!-- <td ><?php echo $row->pangkat; ?></td> -->
		<td style="text-align: left;"><?php echo $row->nama;?></td>
		</tr>
		<?php $no++;?>
		<?php }}} ?>
	</table><br><br>

	<!-- Tabel Untuk Mutasi Petugas Piket -->
    <table border="1" width="100%">
	<tr>
		<th width="6%">No</th>
        <th width="10%">Jam</th>
        <th width="84%">Mutasi</th>
	</tr>

	<?php $no = 1;?>
		<?php foreach ($mutasi as $mutasi): ?>
	<tr>
	<td >
		<?php echo $no ?>
	</td>
	<td >
		<?php echo $mutasi->jam ?>
	</td>
	<td style="text-align: justify;">
		<?php echo $mutasi->mutasi ?>
	</td>
	</tr>
	<?php $no++;?>
	<?php endforeach; ?>
	</table><br><br>

	<p style="text-align: right;">Semarang, <?php echo tanggal_indo($tgl);?></p><br><br>
	<table align="center" width="100%">
		<tr>
		<td style="width: 50% padding-left: 100px">Yang Menerima</td>
        <td style="width: 50% padding-left: 100px">Yang Menyerahkan</td>
    	</tr>
    	<tr>
		<td > <p style="text-align: center; "><img src="<?php echo base_url()?>assets/image/approved.png"></p></td>
        <td > <p style="text-align: center; "><img src="<?php echo base_url()?>assets/image/approved.png"></p></td>
    	</tr>
    	<tr >
		<td ><?php echo $nama_penerima; ?></td>
        <td><?php echo $nama_piket; ?></td>
    	</tr>
    	<tr>
		<td ><img src="<?php echo base_url()?>assets/image/garis.png"></p></td>
        <td ><img src="<?php echo base_url()?>assets/image/garis.png"></td>
    	</tr>
    	<tr>
		<td style="text-align: left; padding-left: 190px">NRP <?php echo $nrp_penerima; ?></td>
        <td style="text-align: left; padding-left: 190px" >NRP <?php echo $nrp_piket; ?></td>
    	</tr>
	</table>

	<table align="center" width="100%">
		<tr>
        <td style="width: 50% padding-left: 100px">Mengetahui Pelaksana</td>
    	</tr>
    	<tr>
        <td >
        	 <?php
			if($status==1)
				{ ?>
	<p style="text-align: center; "><img src="<?php echo base_url()?>assets/image/approved.png"></p>

	 </td>
    	</tr>
    	<tr >
        <td><?php echo $nama_pelaksana; ?></td>
    </tr>
       <tr>
        <td ><img src="<?php echo base_url()?>assets/image/garis.png"></td>
    	</tr>
    	<tr>
        <td style="text-align: left; padding-left: 470px" >NRP <?php echo $nrp_pelaksana; ?></td>
    	</tr>
	<?php } else {
		echo "<br><br><br>";?>
		</td>
    	</tr>
    	<tr >
        <td><?php echo "(Belum dikonfirmasi)" ?></td>
    	</tr>
    	<tr>
        <td ><img src="<?php echo base_url()?>assets/image/garis.png"></td>
    	</tr>
    	<tr>
        <td style="text-align: left; padding-left: 470px" >NRP </td>
    	</tr>
<?php	}?> 

	</table>


	<!-- <p style="text-align: center;">Mengetahui Pelaksana</p><br>
	 <?php
			if($status=="Approved")
				{ ?>
	<p style="text-align: center; "><img src="<?php echo base_url()?>assets/image/approve.png"></p>
	<?php } else {
		echo "<br><br><br>";
	}?> 
	<p style="text-align: center;">Angga Dwi Utomo</p>
	<p style="text-align: center;"><img src="<?php echo base_url()?>assets/image/garis.png"></p><br>
	<p style="margin-left: 435px">NRP <?php echo $nrp_pelaksana; ?></p><br> -->
    <script>
     window.load = print_d();
     function print_d(){
       window.print();
    }
</script>
</body>


</html>