<page backtop="10mm" backbottom="10mm" backleft="10mm" backright="10mm"> 

	<!-- Page Header -->
	<img style="width: 1000px" src="<?php echo base_url()?>assets/image/Header.png">
	<br>

    <?php
    		error_reporting(E_ALL ^ E_NOTICE);
		foreach ($mutasi as $m):
		$var= $m->tanggal;

		endforeach;

		foreach ($nama_penjaga as $st):
		$status= $st->status;
		$date=$st->tgl;
		$nrp_pelaksana= $st->nrp_pelaksana;
		$nrp_penerima= $st->nrp_penerima;
		$nrp_personil= $st->nrp_personil;
		endforeach;
		
		$pieces = explode(",", $nrp_personil);
		foreach($pieces as $element):
			$nrp_piket = $element;
		endforeach;

		$sql ="SELECT * FROM personil where nrp='$nrp_piket'";
			$query = $this->db->query($sql);
			if ($query->num_rows() > 0) {
			foreach ($query->result() as $row) {
				$nrp_piket = $row->nrp;
				$nama_piket = $row->nama;
			}
		}

		$sql ="SELECT * FROM mutasi_personil INNER JOIN personil ON mutasi_personil.nrp_penerima=personil.nrp WHERE mutasi_personil.tgl='$date'";
			$query = $this->db->query($sql);
			if ($query->num_rows() > 0) {
			foreach ($query->result() as $row) {
				$nama_penerima = $row->nama;
			}
		}
		$sql ="SELECT * FROM mutasi_personil INNER JOIN user ON mutasi_personil.nrp_pelaksana=user.nrp WHERE mutasi_personil.tgl='$date'";
			$query = $this->db->query($sql);
			if ($query->num_rows() > 0) {
			foreach ($query->result() as $row) {
				$nama_pelaksana = $row->nama;
			}
		}
	?>

	<?php
       date_default_timezone_set('Asia/Jakarta');

        $tgl=strtotime(date($date));
        $tgl = date('Y-m-d',strtotime('+1day',$tgl));
        
	?>

    <p style="text-align: right;">Hari, Tanggal : <?php if(isset($date)) echo tanggal_indo($date);?></p><br>
    <p>Anggota Piket :</p>
  	

    <style>
		table {
			border-collapse:collapse;
			table-layout:fixed;
			cellpadding:10;
		}
		table td {
			word-wrap:break-word;
			text-align: center;
			padding: 5px;
		}
		table th{
			word-wrap:break-word;
			text-align: center;
			padding: 5px;
		}
		p{
			margin: 0;
			padding: 0;
			border: 0;
			font-size: 100%;
			font: inherit;
			vertical-align: baseline;
		}
	</style>

		<!-- Tabel Untuk Nama Petugas Piket -->
	<table border="1">
	<tr>
		<th >No</th>
        <th >NRP</th>
        <th >Nama</th>
	</tr>

    <?php $no = 1;?>
		<?php 
		foreach ($nama_penjaga as $m):
		$var= $m->nrp_personil ;					

		endforeach;	
		?>
		    <?php
			if(isset($var)){
		    $sql ="SELECT * FROM personil where nrp in ($var) UNION SELECT * FROM user where nrp in ($var)";
			$query = $this->db->query($sql);
			if ($query->num_rows() > 0) {
			foreach ($query->result() as $row) {
	    ?>
		<tr>
		<td style="width: 6%"><?php echo $no;?></td>
		<td style="width: 47%"><?php echo $row->nrp; ?></td>
		<td style="text-align: left; width: 47%"><?php echo $row->nama; ?></td>
		</tr>
		<?php $no++;?>
		<?php }}}?>
	</table><br><br>

	<!-- Tabel Untuk Mutasi Petugas Piket -->
    <table border="1">
	<tr>
		<th >No</th>
        <th >Jam</th>
        <th >Mutasi</th>
	</tr>

    <?php $no = 1;?>
		<?php foreach ($mutasi as $mutasi): ?>
	<tr>
	<td style="width: 6%">
		<?php echo $no ?>
	</td>
	<td style="width: 10%"> 
		<?php echo $mutasi->jam ?>
	</td>
	<td style="text-align: justify; width: 84%">
		<?php echo $mutasi->mutasi ?>
	</td>
	</tr>
	<?php $no++;?>
	<?php endforeach;?>
	</table><br><br>

	<p style="text-align: right;">Semarang, <?php echo tanggal_indo($tgl);?></p><br><br>
	
	<table>
		<tr>
		<td style="width: 50%">Yang Menerima</td>
        <td style="width: 50%">Yang Menyerahkan</td>
    	</tr>
    	<tr>
		<td ><img src="<?php echo base_url()?>assets/image/approved.png"></td>
        <td ><img src="<?php echo base_url()?>assets/image/approved.png"></td>
    	</tr>
    	<tr>
		<td ><?php echo $nama_penerima; ?></td>
        <td ><?php echo $nama_piket; ?></td>
    	</tr>
    	<tr>
		<td ><img src="<?php echo base_url()?>assets/image/garis.png"></td>
        <td ><img src="<?php echo base_url()?>assets/image/garis.png"></td>
    	</tr>
    	<tr>
		<td style="text-align: left; padding-left: 95px">NRP <?php echo $nrp_penerima; ?></td>
        <td style="text-align: left; padding-left: 95px" >NRP <?php echo $nrp_piket; ?></td>
    	</tr>
	</table>
	<table>
		<tr>
			<td style="width: 25%"></td>
		<td style="width: 50%">Mengetahui Pelaksana</td>
		<td style="width: 25%"></td>
    	</tr>
<?php 
	if($status==1){
		?>

    	<tr>
    	<td></td>
        <td><<img src="<?php echo base_url()?>assets/image/approved.png"></td>
        <td></td>
    	</tr>
    	<tr>
    	<td></td>
        <td><?php echo $nama_pelaksana; ?></td>
        <td></td>
    	</tr>
    	<tr>
    	<td></td>
        <td ><img src="<?php echo base_url()?>assets/image/garis.png"></td>
    	<td></td>
    	</tr>
    	<tr>
    	<td></td>
        <td style="text-align: left; padding-left: 95px" >NRP <?php echo $nrp_pelaksana; ?></td>
    	<td></td>
    	</tr>
    	<?php
    }else{?>
    	    	<tr>
    	<td></td>
        <td><br><br><br></td>
        <td></td>
    	</tr>
    	<tr>
    	<td></td>
        <td>(Belum dikonfirmasi)</td>
        <td></td>
    	</tr>
    	<tr>
    	<td></td>
        <td ><img src="<?php echo base_url()?>assets/image/garis.png"></td>
    	<td></td>
    	</tr>
    	<tr>
    	<td></td>
        <td style="text-align: left; padding-left: 95px" >NRP</td>
    	<td></td>
    	</tr>
    <?php }?>
	</table>


	<!-- Page Footert -->
	<page_footer> 
	[[page_cu]]
	</page_footer> 
	
</page> 