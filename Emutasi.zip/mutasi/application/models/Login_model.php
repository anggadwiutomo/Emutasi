<?php
class Login_model extends CI_Model{
    //cek nrp dan password admin
    function auth_admin($username,$password){
        $query=$this->db->query("SELECT * FROM user WHERE nrp='$username' AND pass=MD5('$password') LIMIT 1");
        return $query;
    }
 
    //cek nim dan password petugas
    
    function auth_personil($username,$password){
        $query=$this->db->query("SELECT * FROM personil WHERE nrp='$username' AND pass=MD5('$password') LIMIT 1");
        return $query;
    }

}