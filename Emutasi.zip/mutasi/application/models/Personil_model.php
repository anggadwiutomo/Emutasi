<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Personil_model extends CI_Model
{
    private $_table = "personil";

    public $nrp;
    public $nama;
    public $pangkat;
    public $departemen;
    public $pass;

    public function rules()
    {
        return [
            ['field' => 'nrp',
            'label' => 'NRP',
            'rules' => 'required'],

            ['field' => 'nama_personil',
            'label' => 'Nama Personil',
            'rules' => 'required'],

            ['field' => 'pangkat',
            'label' => 'Pangkat',
            'rules' => 'required'],

            ['field' => 'password',
            'label' => 'password',
            'rules' => 'required'],

            ['field' => 'password_validation',
            'label' => 'password_validation',
            'rules' => 'required|matches[password]']



        ];
    }

    public function list_personil_by_dept($dept_id)
        {
                $this->db->select('*'); 
                $this->db->from('personil');
                $this->db->join('departemen', 'personil.departemen=departemen.dept_id');
                $this->db->join('pangkat', 'personil.pangkat=pangkat.pangkat_id');
                $this->db->where('departemen', $dept_id);
                $query = $this->db->get();
                return $query->result();
        }

    public function get_by_dept()
    {
        $dept = $this->session->userdata['ses_dept'];
        if ($dept=='SUPER')
        {
            return $this->db->get($this->_table)->result();

        }
        else
        {
            $this->db->select('*');
            $this->db->from('personil'); 
            $this->db->where('departemen',$dept);
            $query = $this->db->get();
            return $query->result();
        }

      
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    public function get_detail()
    {
        $dept = $this->session->userdata['ses_dept'];
        $query = $this->db->query("SELECT * FROM personil 
            INNER JOIN departemen ON personil.departemen=departemen.dept_id 
            INNER JOIN pangkat ON personil.pangkat=pangkat.pangkat_id 
            where personil.departemen='$dept'");
        return $query->result();
    }
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["nrp" => $id])->row();
    }

    
    public function get_opt_pangkat()
    {
        $query = $this->db->query('SELECT * FROM pangkat');
        return $query->result();
    }
   
    public function save()
    {
        $post = $this->input->post();
        $dept = $this->session->userdata['ses_dept'];
        $this->nrp = $post["nrp"];
        $this->nama = $post["nama_personil"];
        $this->pangkat = $post["pangkat"];
        $this->departemen = $dept;
        $this->pass = md5($post["password"]);
        $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $dept = $this->session->userdata['ses_dept'];
        $post = $this->input->post();

        $this->nrp = $post["nrp"];
        $this->nama = $post["nama_personil"];
        $this->pangkat = $post["pangkat"];
        $this->departemen = $dept;
        $this->pass = md5($post["password"]);
        $this->db->update($this->_table, $this, array('nrp' => $post['id']));

    }

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("nrp" => $id));
    }

    ///Edit password
   public function get_user($id)
    {
        $this->db->where('nrp', $id);
        $query = $this->db->get('personil');
        return $query->row();
    }

    public function update_user($id, $userdata)
    {
        $this->db->where('nrp', $id);
        $this->db->update('personil', $userdata);
    }

    public function get_user2($id)
    {
        $level = 2;
        $this->db->where('nrp', $id);
         $this->db->where('level', $level);
        $query = $this->db->get('user');
        return $query->row();
    }

    public function update_user2($id, $userdata)
    {
        $level = 2;
        $this->db->where('nrp', $id);
         $this->db->where('level', $level);
        $this->db->update('user', $userdata);
    }
    public function get_user1($id)
    {
        $level = 1;
        $this->db->where('nrp', $id);
         $this->db->where('level', $level);
        $query = $this->db->get('user');
        return $query->row();
    }

    public function update_user1($id, $userdata)
    {
        $level = 1;
        $this->db->where('nrp', $id);
         $this->db->where('level', $level);
        $this->db->update('user', $userdata);
    }
    

   
}