<?php defined('BASEPATH') OR exit('No direct script access allowed');

class mutasi_model extends CI_Model
{
    private $_table = "mutasi";
    private $_tablePiket = "mutasi_personil";



    public $mutasi_id;
    public $tanggal;
    public $nama_petugas;
    public $jam;
    public $mutasi;

  
    public function rules()
    {
        return [

            ['field' => 'mutasi',
            'label' => 'Mutasi',
            'rules' => 'required']
        ];
    }
    public function rules2()
    {
        return [

            ['field' => 'tanggal',
            'label' => 'tanggal',
            'rules' => 'required']
        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    public function get_all_mutasi()
    {
                $query = $this->db->query("SELECT * FROM mutasi INNER JOIN departemen ON mutasi.departemen=departemen.dept_id 
                    ORDER BY mutasi.tanggal DESC");
                return $query->result();
    }
    public function get_opt_nama()
    {
       
         $dept = $this->session->userdata['ses_dept'];
            $query = $this->db->query("SELECT * FROM personil WHERE departemen='$dept'");
             return $query->result();

       

    }
    public function get_opt_admin()
    {
       
         $dept = $this->session->userdata['ses_dept'];
            $query = $this->db->query(" SELECT * FROM user WHERE departemen='$dept' and level='2' ");
             return $query->result();

       

    }
    public function get_daftar_mutasi(){

                $query = $this->db->query("SELECT * FROM mutasi_personil INNER JOIN departemen ON mutasi_personil.departemen=departemen.dept_id ORDER BY tgl DESC");
                return $query->result();


    }
     public function get_daftar_mutasi2(){

               $dept = $this->session->userdata['ses_dept'];
                $query = $this->db->query("SELECT * FROM mutasi_personil  INNER JOIN departemen ON mutasi_personil.departemen=departemen.dept_id where departemen='$dept' ORDER BY tgl DESC");
                return $query->result();


    }
    public function get_nama_piket()
    {
        $dept = $this->session->userdata['ses_dept'];
        $sub_kalimat = substr($dept,4);
        date_default_timezone_set('Asia/Jakarta');
        $tgl=strtotime(date('ymd'));
        $clock=date('H:i');
        if (date('H')>=0 AND date('H')<8)
        {
            $tgl = date('ymd',strtotime('-1day',$tgl));
            $idunik = $tgl.$sub_kalimat;
        }
        else
        {
            $tgl = date('ymd',strtotime('today',$tgl));
            $idunik = $tgl.$sub_kalimat;
        }
        $query = $this->db->query("SELECT * FROM mutasi_personil where id='$idunik' ");
        return $query->result();
    }
    public function get_mutasi()
    {
        date_default_timezone_set('Asia/Jakarta');
         $tgl=strtotime(date('Y-m-d'));

         if (date('H')>=0 AND date('H')<8)
        {
            $tgl = date('Y-m-d',strtotime('-1day',$tgl));
        }
        else
        {
            $tgl = date('Y-m-d',strtotime('today',$tgl));
        }
        $date = new DateTime("now");
        $curr_date = $date->format('Y-m-d');
        $dept = $this->session->userdata['ses_dept'];
        
            $this->db->select('*');
            $this->db->from('mutasi'); 
            $this->db->where('tanggal',$tgl);//use date function
            $this->db->where('departemen',$dept);
            $query = $this->db->get();
            return $query->result();
              
    }
     public function list_nama_by_mutasi($nama_petugas)
        {
                $this->db->select('*'); 
                $this->db->where('id', $nama_petugas);
                $query = $this->db->get('mutasi_personil');
                return $query->result();
        }
         public function list_mutasi_by_nama($nama_petugas)
        {
                $this->db->select('*'); 
                                $this->db->from('mutasi');
                $this->db->join('departemen', 'mutasi.departemen=departemen.dept_id');

                $this->db->where('nama_petugas', $nama_petugas);
                $query = $this->db->get();
                return $query->result();
        }
            public function list_nama_by_mutasi2($nama_petugas)
        {
                    $dept = $this->session->userdata['ses_dept'];

                $this->db->select('*'); 
                $this->db->where('id', $nama_petugas);
                $this->db->where('departemen', $dept);
                $query = $this->db->get('mutasi_personil');
                return $query->result();
        }
         public function list_mutasi_by_nama2($nama_petugas)
        {
                    $dept = $this->session->userdata['ses_dept'];

                $this->db->select('*'); 
                $this->db->where('nama_petugas', $nama_petugas);
                                $this->db->where('departemen', $dept);
                $query = $this->db->get('mutasi');
                return $query->result();
        }
        public function list_mutasi_personil($nama_petugas)
        {
                $this->db->select('*'); 
                $this->db->where('id', $nama_petugas);
                $query = $this->db->get('mutasi_personil');
                return $query->result();
        }


    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["mutasi_id" => $id])->row();
    }
     public function getByIdPiket($id)
    {
        return $this->db->get_where($this->_tablePiket, ["id" => $id])->row();
    }

    public function get_no_invoice(){
        $dept = $this->session->userdata['ses_dept'];
        $sub_kalimat = substr($dept,4);
        date_default_timezone_set('Asia/Jakarta');
        $tgl=strtotime(date('ymd'));
        $clock=date('H:i');
        if (date('H')>=0 AND date('H')<8)
        {
            $tgl = date('ymd',strtotime('-1day',$tgl));
            return $tgl.$sub_kalimat;
        }
        else
        {
            $tgl = date('ymd',strtotime('today',$tgl));
               return $tgl.$sub_kalimat;
        }
     
    }
 
    public function save()
    {
        $dept = $this->session->userdata['ses_dept'];
        $sub_kalimat = substr($dept,4);
        date_default_timezone_set('Asia/Jakarta');
        $tgl=strtotime(date('ymd'));
        $clock=date('H:i');
        if (date('H')>=0 AND date('H')<8)
        {
            $tgl = date('ymd',strtotime('-1day',$tgl));
            $idunik = $tgl.$sub_kalimat;
        }
        else
        {
            $tgl = date('ymd',strtotime('today',$tgl));
            $idunik = $tgl.$sub_kalimat;
        }
        

        $query=$this->db->get('mutasi');
        $date = new DateTime("now");
        $curr_date = $date->format('Y-m-d');

        $post = $this->input->post();
        $dept = $this->session->userdata['ses_dept'];
        $this->mutasi_id = uniqid();
        $this->tanggal = $post["tanggal"];
        $this->departemen = $dept;
        $this->nama_petugas = $idunik;
        $this->jam = $post["jam"];
        $this->mutasi = $post["mutasi"];
        $this->db->insert($this->_table, $this);

 
    }

    public function savePiket()
    {
        $post = $this->input->post();
        $dept = $this->session->userdata['ses_dept'];
        date_default_timezone_set('Asia/Jakarta');
        $today=strtotime(date('Y-m-d'));
        $clock=date('H:i');
        if (date('H')>=0 AND date('H')<8)
        {
            $today = date('Y-m-d',strtotime('-1day',$today));
        }
        else
        {
            $today = date('Y-m-d',strtotime('today',$today));
        }


        $id = $post["tanggal"];
        $tgl = $today;
        $departemen = $dept;
        $nrp_personil = implode(',', $_POST['nama_petugas']);
        $nrp_pelaksana = $post["nama_pelaksana"];
        $nrp_penerima = $post["nama_penerima"];
        $status = 0;
        $sql = "INSERT INTO mutasi_personil (id,tgl,departemen, nrp_personil, nrp_pelaksana, nrp_penerima, status)
        VALUES ('$id','$tgl','$dept' ,'$nrp_personil', '$nrp_pelaksana', '$nrp_penerima', '$status')";
        $query = $this->db->query($sql);

    }
    public function updatePiket()
    {
        $post = $this->input->post();

        // $this->id = $post["id"];
        // $this->nrp_personil = implode(',', $_POST['nama_petugas']);
        // $this->db->update($this->_tablePiket, $this, array('id' => $post['id']));
        $id=$post["id"];
        $nrp_personil=implode(',', $_POST['nama_petugas']);
        $nrp_pelaksana = $post["nama_pelaksana"];
        $nrp_penerima = $post["nama_penerima"];
        $sql = "UPDATE mutasi_personil SET nrp_personil='$nrp_personil', nrp_pelaksana='$nrp_pelaksana', nrp_penerima='$nrp_penerima'  WHERE id='$id'";
        $query = $this->db->query($sql);

    }
  
    public function updateStatus($id)
    {
        $status = $this->status = 1;
        // $this->db->update($this->_table, $this, array('mutasi_id' => $post['id']));
        $sql = "UPDATE mutasi_personil SET status='$status' WHERE id='$id'";
        $query = $this->db->query($sql);


    }

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("mutasi_id" => $id));
    }


    //Filter
    public function view_by_date($date){
        $this->db->where('DATE(tanggal)', $date); // Tambahkan where tanggal nya
        $this->db->order_by('tanggal', 'desc');
        
        return $this->db->get('mutasi')->result();// Tampilkan data mutasi sesuai tanggal yang diinput oleh user pada filter
    }
    
    public function view_by_month($month, $year){
        $this->db->where('MONTH(tanggal)', $month); // Tambahkan where bulan
        $this->db->where('YEAR(tanggal)', $year); // Tambahkan where tahun
        $this->db->order_by('tanggal', 'desc');
        
        return $this->db->get('mutasi')->result(); // Tampilkan data mutasi sesuai bulan dan tahun yang diinput oleh user pada filter
    }
    
    public function view_by_year($year){
        $this->db->where('YEAR(tanggal)', $year); // Tambahkan where tahun
        $this->db->order_by('tanggal', 'desc');
        
        return $this->db->get('mutasi')->result(); // Tampilkan data mutasi sesuai tahun yang diinput oleh user pada filter
    }
    
    public function view_all(){

        $this->db->order_by('tanggal', 'desc');
        $this->db->join('departemen','mutasi.departemen=departemen.dept_id');
        return $this->db->get('mutasi')->result(); // Tampilkan semua data mutasi
    }
    
    public function option_tahun(){
        $this->db->select('YEAR(tanggal) AS tahun'); // Ambil Tahun dari field tanggal
        $this->db->from('mutasi'); // select ke tabel mutasi
        $this->db->order_by('YEAR(tanggal)','desc'); // Urutkan berdasarkan tahun secara Ascending (ASC)
        $this->db->group_by('YEAR(tanggal)'); // Group berdasarkan tahun pada field tanggal
        
        return $this->db->get()->result(); // Ambil data pada tabel mutasi sesuai kondisi diatas
    }




     //Filter Untuk Admin perdepartemen
    public function view_by_date2($date){
        $dept = $this->session->userdata['ses_dept'];
        $this->db->where('departemen',$dept);

        $this->db->where('DATE(tanggal)', $date); // Tambahkan where tanggal nya
        $this->db->order_by('tanggal', 'desc');
        

        return $this->db->get('mutasi')->result();// Tampilkan data mutasi sesuai tanggal yang diinput oleh user pada filter
    }
    
    public function view_by_month2($month, $year){
        $dept = $this->session->userdata['ses_dept'];
        $this->db->where('departemen',$dept);

        $this->db->where('MONTH(tanggal)', $month); // Tambahkan where bulan
        $this->db->where('YEAR(tanggal)', $year); // Tambahkan where tahun
        $this->db->order_by('tanggal', 'desc');
        
        return $this->db->get('mutasi')->result(); // Tampilkan data mutasi sesuai bulan dan tahun yang diinput oleh user pada filter
    }
    
    public function view_by_year2($year){
        $dept = $this->session->userdata['ses_dept'];
        $this->db->where('departemen',$dept);

        $this->db->where('YEAR(tanggal)', $year); // Tambahkan where tahun
        $this->db->order_by('tanggal', 'desc');
        
        return $this->db->get('mutasi')->result(); // Tampilkan data mutasi sesuai tahun yang diinput oleh user pada filter
    }
    
    public function view_all2(){
        $dept = $this->session->userdata['ses_dept'];
        $this->db->where('departemen',$dept);
        $this->db->order_by('tanggal', 'desc');

        return $this->db->get('mutasi')->result(); // Tampilkan semua data mutasi
    }
    
    public function option_tahun2(){
        $dept = $this->session->userdata['ses_dept'];
        $this->db->where('departemen',$dept);

        $this->db->select('YEAR(tanggal) AS tahun'); // Ambil Tahun dari field tanggal
        $this->db->from('mutasi'); // select ke tabel mutasi
        $this->db->order_by('YEAR(tanggal)','desc'); // Urutkan berdasarkan tahun secara Ascending (ASC)
        $this->db->group_by('YEAR(tanggal)'); // Group berdasarkan tahun pada field tanggal
        
        return $this->db->get()->result(); // Ambil data pada tabel mutasi sesuai kondisi diatas
    }



    ///Filter Dengan Pilihan Departemen
    public function view_by_date3($date){
        $this->db->where('DATE(tanggal)', $date); // Tambahkan where tanggal nya
         $this->db->join('departemen','mutasi.departemen=departemen.dept_id');
        $this->db->order_by('tanggal', 'desc');
        return $this->db->get('mutasi')->result();// Tampilkan data mutasi sesuai tanggal yang diinput oleh user pada filter
    }

    public function view_by_dept3($dept){
        $this->db->where('departemen', $dept); // Tambahkan where tahun
        $this->db->order_by('tanggal', 'desc');
         $this->db->join('departemen','mutasi.departemen=departemen.dept_id');
        return $this->db->get('mutasi')->result(); // Tampilkan data mutasi sesuai bulan dan tahun yang diinput oleh user pada filter
    }
    
    public function view_by_date_dept3($date, $dept){
        $this->db->where('DATE(tanggal)', $date); // Tambahkan where bulan
        $this->db->where('departemen', $dept); // Tambahkan where tahun
         $this->db->join('departemen','mutasi.departemen=departemen.dept_id');
        $this->db->order_by('tanggal', 'desc');
        return $this->db->get('mutasi')->result(); // Tampilkan data mutasi sesuai bulan dan tahun yang diinput oleh user pada filter
    }

    public function view_all3(){
        $this->db->order_by('tanggal', 'desc');
        return $this->db->get('mutasi')->result(); // Tampilkan semua data mutasi
    }

     public function getDepartemen()
    {
        $query = $this->db->query('SELECT * FROM departemen');
        return $query->result();
    }
    public function update()
    {
        $post = $this->input->post();
        $this->mutasi_id = $post["id"];
        $this->tanggal = $post["tanggal"];
        $this->nama_petugas = $post["nama_petugas"];
        $this->jam = $post["jam"];
        $this->mutasi = $post["mutasi"];
        $this->db->update($this->_table, $this, array('mutasi_id' => $post['id']));

    }
 

}