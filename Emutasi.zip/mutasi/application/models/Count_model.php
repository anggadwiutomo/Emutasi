<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Count_model extends CI_model {

    // Hitung Client
    public function client()
    {
        return $this->db->query("SELECT * FROM personil");
    }
    //
    // Hitung Admin
    public function admin()
    {
        return $this->db->query("SELECT * FROM user where level='2'");
    }
    // Hitung Departemen
    public function departemen()
    {
        return $this->db->query("SELECT * FROM departemen");
    }
     // Hitung Mutasi
    public function mutasi()
    {
        return $this->db->query("SELECT * FROM mutasi_personil");
    }
       // Hitung Admin
    public function admin_departemen()
    {
        $dept = $this->session->userdata['ses_dept'];
        return $this->db->query("SELECT * FROM user where departemen='$dept' AND level='2' ");
    }
     // Hitung Client
    public function personil_departemen()
    {
        $dept = $this->session->userdata['ses_dept'];
        return $this->db->query("SELECT * FROM personil where departemen='$dept' ");
    }
     public function mutasi_departemen()
    {
                $dept = $this->session->userdata['ses_dept'];
        return $this->db->query("SELECT * FROM mutasi_personil where departemen='$dept' ");
    }
    public function get_nama_piket()
    {
        $dept = $this->session->userdata['ses_dept'];
        $sub_kalimat = substr($dept,4);
        date_default_timezone_set('Asia/Jakarta');
        $tgl=strtotime(date('ymd'));
        $clock=date('H:i');
        if (date('H')>=0 AND date('H')<8)
        {
            $tgl = date('ymd',strtotime('-1day',$tgl));
            $idunik = $tgl.$sub_kalimat;
        }
        else
        {
            $tgl = date('ymd',strtotime('today',$tgl));
            $idunik = $tgl.$sub_kalimat;
        }
        $query = $this->db->query("SELECT * FROM mutasi_personil where id='$idunik' ");
        return $query->result();
    }  		
}
