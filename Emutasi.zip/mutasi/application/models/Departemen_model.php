<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Departemen_model extends CI_Model
{
    private $_table = "departemen";

    public $dept_id;
    public $nama_dept;
  
    public function rules()
    {
        return [
            ['field' => 'dept_id',
            'label' => 'Departemen Id',
            'rules' => 'required'],

            ['field' => 'nama_dept',
            'label' => 'Nama Departemen',
            'rules' => 'required']
        ];
    }

    public function rules_cabang()
    {
        return [
            ['field' => 'dept_cabang_id',
            'label' => 'ID Departemen Cabang',
            'rules' => 'required']
        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    
    public function buat_kode()

    {
        $this->db->select('RIGHT(departemen.dept_id,3) as kode', FALSE);
        $this->db->order_by('dept_id','DESC');
        $this->db->limit(1);

        $query=$this->db->get('departemen');

        if ($query->num_rows()!=0) 
        {
           $data=$query->row();
           $kode=intval($data->kode)+1;
        } 
        else
        {
            $kode=1;
        }
        $kode_max=str_pad($kode,3,"0",STR_PAD_LEFT);
        $kode_jadi="DEPT-".$kode_max;
        return $kode_jadi;
   }
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["dept_id" => $id])->row();
    }

    public function save()
    {
        $post = $this->input->post();
        $this->dept_id = $post["dept_id"];
        $this->nama_dept = $post["nama_dept"];
        $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $post = $this->input->post();
        $this->dept_id = $post["dept_id"];
        $this->nama_dept = $post["nama_dept"];
        $this->db->update($this->_table, $this, array('dept_id' => $post['id']));

    }

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("dept_id" => $id));
    }
    private function _uploadImage()
    {
    $config['upload_path']          = './upload/product/';
    $config['allowed_types']        = 'gif|jpg|png';
    $config['file_name']            = $this->product_id;
    $config['overwrite']			= true;
    $config['max_size']             = 1024; // 1MB
    // $config['max_width']            = 1024;
    // $config['max_height']           = 768;

    $this->load->library('upload', $config);

    if ($this->upload->do_upload('image')) {
        return $this->upload->data("file_name");
    }
    
    return "default.jpg";
    }


    ///Kode Unik Departemen Cabang
    public function buat_kode_cabang()
    {
        $this->db->select('RIGHT(departemen_cabang.dept_cabang_id,3) as kode_cabang', FALSE);
        $this->db->order_by('dept_cabang_id','DESC');
        $this->db->limit(1);

        $query=$this->db->get('departemen_cabang');

        if ($query->num_rows()!=0) 
        {
           $data=$query->row();
           $kode_cabang=intval($data->kode_cabang)+1;
        } 
        else
        {
            $kode_cabang=1;
        }
        $kode_max=str_pad($kode_cabang,3,"0",STR_PAD_LEFT);
        $kode_jadi="CAB-".$kode_max;
        return $kode_jadi;
   }

   public function getDepartemen()
    {
        $query = $this->db->query('SELECT * FROM departemen');
        return $query->result();
    }

    public function save_cabang()
    {
        $post = $this->input->post();
        $dept_cabang_id = $post["dept_cabang_id"];
        $dept_id = $post["dept_id"];
        $nama_dept_cabang = $post["nama_dept_cabang"];
        $sql = "INSERT INTO departemen_cabang (dept_cabang_id,dept_id,nama_dept_cabang)
        VALUES ('$dept_cabang_id','$dept_id','$nama_dept_cabang')";
        $query = $this->db->query($sql);
    }

    ///Chained Dropdown
    public function view(){
        return $this->db->get('departemen')->result(); // Tampilkan semua data yang ada di tabel departemen
    }

    public function viewByDepartemen($dept_id){
        $this->db->where('dept_id', $dept_id);
        $result = $this->db->get('departemen_cabang')->result(); // Tampilkan semua data kota berdasarkan id departemen
        
        return $result; 
    }
}