<?php defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model
{
    private $_table = "user";


    public $nrp;
    public $nama;
    public $pangkat;
    public $pass;
    public $level;

    public function rules()
    {
        return [
            ['field' => 'nrp',
            'label' => 'NRP',
            'rules' => 'required'],

            ['field' => 'nama',
            'label' => 'Nama',
            'rules' => 'required'],

            ['field' => 'pangkat',
            'label' => 'Pangkat',
            'rules' => 'required'],

            ['field' => 'password',
            'label' => 'password',
            'rules' => 'required'],

            ['field' => 'password_validation',
            'label' => 'password_validation',
            'rules' => 'required|matches[password]']
        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    public function getDetail()
    {
        $query = $this->db->query("SELECT * FROM user 
            INNER JOIN departemen ON user.departemen=departemen.dept_id 
            INNER JOIN pangkat ON user.pangkat=pangkat.pangkat_id ");
        return $query->result();
    }
    public function getDepartemen()
    {
        $query = $this->db->query('SELECT * FROM departemen');
        return $query->result();
    }
    public function getPangkat()
    {
        $query = $this->db->query('SELECT * FROM pangkat');
        return $query->result();
    }
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["nrp" => $id])->row();
    }

    public function save()
    {
        $post = $this->input->post();

        $this->nrp = $post["nrp"];
        $this->nama = $post["nama"];
        $this->pangkat = $post["pangkat"];
        $this->pass = md5($post["password"]);
        $this->level = $post["level"];
        $this->departemen = $post["departemen"];
        $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $post = $this->input->post();

        $this->nrp = $post["nrp"];
        $this->nama = $post["nama"];
        $this->pangkat = $post["pangkat"];
        $this->pass = md5($post["password"]);
        $this->level = $post["level"];
        $this->departemen = $post["departemen"];
        $this->db->update($this->_table, $this, array('nrp' => $post['id']));

    }

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("nrp" => $id));
    }
   
}